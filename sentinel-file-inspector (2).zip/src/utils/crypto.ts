/**
 * Cybersecurity Cryptographic & Binary Analysis Utilities
 * Zero-execution static analysis engine running client-side in the browser.
 */

// Pure TypeScript implementation of MD5 (RFC 1321) for client-side hashing
export function calculateMD5(bytes: Uint8Array): string {
  function safeAdd(x: number, y: number): number {
    const lsw = (x & 0xffff) + (y & 0xffff);
    const msw = (x >> 16) + (y >> 16) + (lsw >> 16);
    return (msw << 16) | (lsw & 0xffff);
  }

  function bitRol(num: number, cnt: number): number {
    return (num << cnt) | (num >>> (32 - cnt));
  }

  function md5cmn(q: number, a: number, b: number, x: number, s: number, t: number): number {
    return safeAdd(bitRol(safeAdd(safeAdd(a, q), safeAdd(x, t)), s), b);
  }
  function md5ff(a: number, b: number, c: number, d: number, x: number, s: number, t: number): number {
    return md5cmn((b & c) | (~b & d), a, b, x, s, t);
  }
  function md5gg(a: number, b: number, c: number, d: number, x: number, s: number, t: number): number {
    return md5cmn((b & d) | (c & ~d), a, b, x, s, t);
  }
  function md5hh(a: number, b: number, c: number, d: number, x: number, s: number, t: number): number {
    return md5cmn(b ^ c ^ d, a, b, x, s, t);
  }
  function md5ii(a: number, b: number, c: number, d: number, x: number, s: number, t: number): number {
    return md5cmn(c ^ (b | ~d), a, b, x, s, t);
  }

  const n = bytes.length;
  const words: number[] = [];
  for (let i = 0; i < n; i++) {
    words[i >> 2] = (words[i >> 2] || 0) | (bytes[i] << ((i % 4) * 8));
  }
  words[n >> 2] = (words[n >> 2] || 0) | (0x80 << ((n % 4) * 8));
  const totalLengthWords = (((n + 8) >> 6) + 1) * 16;
  words[totalLengthWords - 2] = n * 8;
  words[totalLengthWords - 1] = Math.floor((n * 8) / 0x100000000);

  let a = 1732584193;
  let b = -271733879;
  let c = -1732584194;
  let d = 271733878;

  for (let i = 0; i < totalLengthWords; i += 16) {
    const olda = a;
    const oldb = b;
    const oldc = c;
    const oldd = d;

    const w = (idx: number) => words[i + idx] || 0;

    a = md5ff(a, b, c, d, w(0), 7, -680876936);
    d = md5ff(d, a, b, c, w(1), 12, -389564586);
    c = md5ff(c, d, a, b, w(2), 17, 606105819);
    b = md5ff(b, c, d, a, w(3), 22, -1044525330);
    a = md5ff(a, b, c, d, w(4), 7, -176418897);
    d = md5ff(d, a, b, c, w(5), 12, 1200080426);
    c = md5ff(c, d, a, b, w(6), 17, -1473231341);
    b = md5ff(b, c, d, a, w(7), 22, -45705983);
    a = md5ff(a, b, c, d, w(8), 7, 1770035416);
    d = md5ff(d, a, b, c, w(9), 12, -1958414417);
    c = md5ff(c, d, a, b, w(10), 17, -42063);
    b = md5ff(b, c, d, a, w(11), 22, -1990404162);
    a = md5ff(a, b, c, d, w(12), 7, 1804603682);
    d = md5ff(d, a, b, c, w(13), 12, -40341101);
    c = md5ff(c, d, a, b, w(14), 17, -1502002290);
    b = md5ff(b, c, d, a, w(15), 22, 1236535329);

    a = md5gg(a, b, c, d, w(1), 5, -165796510);
    d = md5gg(d, a, b, c, w(6), 9, -1069501632);
    c = md5gg(c, d, a, b, w(11), 14, 643717713);
    b = md5gg(b, c, d, a, w(0), 20, -373897302);
    a = md5gg(a, b, c, d, w(5), 5, -701558691);
    d = md5gg(d, a, b, c, w(10), 9, 38016083);
    c = md5gg(c, d, a, b, w(15), 14, -660478335);
    b = md5gg(b, c, d, a, w(4), 20, -405537848);
    a = md5gg(a, b, c, d, w(9), 5, 568446438);
    d = md5gg(d, a, b, c, w(14), 9, -1019803690);
    c = md5gg(c, d, a, b, w(3), 14, -187363961);
    b = md5gg(b, c, d, a, w(8), 20, 1163531501);
    a = md5gg(a, b, c, d, w(13), 5, -1444681467);
    d = md5gg(d, a, b, c, w(2), 9, -51403784);
    c = md5gg(c, d, a, b, w(7), 14, 1735328473);
    b = md5gg(b, c, d, a, w(12), 20, -1926607734);

    a = md5hh(a, b, c, d, w(5), 4, -378558);
    d = md5hh(d, a, b, c, w(8), 11, -2022574463);
    c = md5hh(c, d, a, b, w(11), 16, 1839030562);
    b = md5hh(b, c, d, a, w(14), 23, -35309556);
    a = md5hh(a, b, c, d, w(1), 4, -1530992060);
    d = md5hh(d, a, b, c, w(4), 11, 1272893353);
    c = md5hh(c, d, a, b, w(7), 16, -155497632);
    b = md5hh(b, c, d, a, w(10), 23, -1094730640);
    a = md5hh(a, b, c, d, w(13), 4, 681279174);
    d = md5hh(d, a, b, c, w(0), 11, -358537222);
    c = md5hh(c, d, a, b, w(3), 16, -722521979);
    b = md5hh(b, c, d, a, w(6), 23, 76029189);
    a = md5hh(a, b, c, d, w(9), 4, -640364487);
    d = md5hh(d, a, b, c, w(12), 11, -421815835);
    c = md5hh(c, d, a, b, w(15), 16, 530742520);
    b = md5hh(b, c, d, a, w(2), 23, -995338651);

    a = md5ii(a, b, c, d, w(0), 6, -198630844);
    d = md5ii(d, a, b, c, w(7), 10, 1126891415);
    c = md5ii(c, d, a, b, w(14), 15, -1416354905);
    b = md5ii(b, c, d, a, w(5), 21, -57434055);
    a = md5ii(a, b, c, d, w(12), 6, 1700485571);
    d = md5ii(d, a, b, c, w(3), 10, -1894986606);
    c = md5ii(c, d, a, b, w(10), 15, -1051523);
    b = md5ii(b, c, d, a, w(1), 21, -2054922799);
    a = md5ii(a, b, c, d, w(8), 6, 1873313359);
    d = md5ii(d, a, b, c, w(15), 10, -30611744);
    c = md5ii(c, d, a, b, w(6), 15, -1560198380);
    b = md5ii(b, c, d, a, w(13), 21, 1309151649);
    a = md5ii(a, b, c, d, w(4), 6, -145523070);
    d = md5ii(d, a, b, c, w(11), 10, -1120210379);
    c = md5ii(c, d, a, b, w(2), 15, 718787259);
    b = md5ii(b, c, d, a, w(9), 21, -343485551);

    a = safeAdd(a, olda);
    b = safeAdd(b, oldb);
    c = safeAdd(c, oldc);
    d = safeAdd(d, oldd);
  }

  function toHex(val: number): string {
    let s = '';
    for (let j = 0; j <= 3; j++) {
      s += ((val >> (j * 8)) & 255).toString(16).padStart(2, '0');
    }
    return s;
  }

  return `${toHex(a)}${toHex(b)}${toHex(c)}${toHex(d)}`.toLowerCase();
}

// Web Crypto SHA-256 and SHA-1 calculation
export async function calculateWebCryptoHash(buffer: ArrayBuffer, algorithm: 'SHA-256' | 'SHA-1'): Promise<string> {
  if (typeof crypto !== 'undefined' && crypto.subtle) {
    const hashBuffer = await crypto.subtle.digest(algorithm, buffer);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  }
  return 'crypto_unavailable';
}

// Calculate Shannon Entropy: H = -sum(p_i * log2(p_i))
export function calculateShannonEntropy(bytes: Uint8Array): {
  entropy: number;
  byteDistribution: number[];
  interpretation: 'Low (Structured/Text)' | 'Normal (Standard data)' | 'High (Compressed/Encrypted/Packed)';
} {
  const counts = new Uint32Array(256);
  const len = bytes.length;

  if (len === 0) {
    return {
      entropy: 0,
      byteDistribution: new Array(256).fill(0),
      interpretation: 'Low (Structured/Text)',
    };
  }

  for (let i = 0; i < len; i++) {
    counts[bytes[i]]++;
  }

  let entropy = 0;
  for (let i = 0; i < 256; i++) {
    if (counts[i] > 0) {
      const p = counts[i] / len;
      entropy -= p * Math.log2(p);
    }
  }

  // Normalize counts to a 256-array of values 0-100 for distribution plotting
  const maxCount = Math.max(...counts, 1);
  const byteDistribution = Array.from(counts).map(c => Math.round((c / maxCount) * 100));

  let interpretation: 'Low (Structured/Text)' | 'Normal (Standard data)' | 'High (Compressed/Encrypted/Packed)';
  if (entropy < 4.8) {
    interpretation = 'Low (Structured/Text)';
  } else if (entropy <= 7.1) {
    interpretation = 'Normal (Standard data)';
  } else {
    interpretation = 'High (Compressed/Encrypted/Packed)';
  }

  return {
    entropy: Number(entropy.toFixed(3)),
    byteDistribution,
    interpretation,
  };
}

// Extract printable ASCII strings (>= minLength) and tag suspicious indicators
export function extractStrings(
  bytes: Uint8Array,
  minLength = 4,
  maxStrings = 300
): Array<{
  str: string;
  offset: number;
  isSuspicious: boolean;
  category?: 'network' | 'execution' | 'registry' | 'cryptography' | 'persistence' | 'general';
}> {
  const results: Array<{
    str: string;
    offset: number;
    isSuspicious: boolean;
    category?: 'network' | 'execution' | 'registry' | 'cryptography' | 'persistence' | 'general';
  }> = [];

  let currentStr = '';
  let startOffset = 0;

  const suspiciousPatterns: Array<{
    regex: RegExp;
    category: 'network' | 'execution' | 'registry' | 'cryptography' | 'persistence' | 'general';
  }> = [
    { regex: /https?:\/\/[^\s]+/i, category: 'network' },
    { regex: /\b(?:\d{1,3}\.){3}\d{1,3}\b/, category: 'network' },
    { regex: /(powershell|cmd\.exe|wscript|cscript|rundll32|regsvr32|certutil|bash|\/bin\/sh)/i, category: 'execution' },
    { regex: /(VirtualAlloc|WriteProcessMemory|CreateRemoteThread|LoadLibrary|GetProcAddress|ShellExecute)/i, category: 'execution' },
    { regex: /(CurrentVersion\\Run|HKEY_LOCAL_MACHINE|HKEY_CURRENT_USER|SOFTWARE\\Microsoft)/i, category: 'registry' },
    { regex: /(base64|AES|RSA|decrypt|encrypt|payload|obfus)/i, category: 'cryptography' },
    { regex: /(schtasks|crontab|systemctl|persistence|autostart|startup)/i, category: 'persistence' },
    { regex: /(eval\(|Invoke-Expression|IEX|DownloadString|DownloadFile)/i, category: 'execution' },
  ];

  for (let i = 0; i < bytes.length; i++) {
    const b = bytes[i];
    // Printable ASCII: 32 (space) to 126 (~)
    if (b >= 32 && b <= 126) {
      if (currentStr.length === 0) startOffset = i;
      currentStr += String.fromCharCode(b);
    } else {
      if (currentStr.length >= minLength) {
        let isSuspicious = false;
        let matchedCategory: 'network' | 'execution' | 'registry' | 'cryptography' | 'persistence' | 'general' = 'general';

        for (const pattern of suspiciousPatterns) {
          if (pattern.regex.test(currentStr)) {
            isSuspicious = true;
            matchedCategory = pattern.category;
            break;
          }
        }

        results.push({
          str: currentStr,
          offset: startOffset,
          isSuspicious,
          category: matchedCategory,
        });

        if (results.length >= maxStrings) break;
      }
      currentStr = '';
    }
  }

  return results;
}

// Magic bytes header identification
export function detectMagicBytes(bytes: Uint8Array, filename: string): {
  detectedType: string;
  magicHex: string;
  isMismatch: boolean;
  category: string;
} {
  const hex = Array.from(bytes.slice(0, 8))
    .map(b => b.toString(16).padStart(2, '0').toUpperCase())
    .join(' ');

  const ext = filename.split('.').pop()?.toLowerCase() || '';

  // Signatures
  if (bytes[0] === 0x4d && bytes[1] === 0x5a) {
    const isMismatch = ext === 'pdf' || ext === 'jpg' || ext === 'png' || ext === 'txt' || ext === 'docx';
    return {
      detectedType: 'Windows PE Executable / DLL (MZ)',
      magicHex: hex,
      isMismatch,
      category: 'executables',
    };
  }

  if (bytes[0] === 0x7f && bytes[1] === 0x45 && bytes[2] === 0x4c && bytes[3] === 0x46) {
    return {
      detectedType: 'Linux ELF Executable / Shared Object',
      magicHex: hex,
      isMismatch: ext !== 'elf' && ext !== 'so' && ext !== 'bin' && ext !== '',
      category: 'executables',
    };
  }

  if (bytes[0] === 0x50 && bytes[1] === 0x4b && (bytes[2] === 0x03 || bytes[2] === 0x05 || bytes[2] === 0x07)) {
    let type = 'ZIP Archive';
    if (ext === 'apk') type = 'Android Application Package (APK / ZIP)';
    else if (ext === 'jar') type = 'Java Archive (JAR / ZIP)';
    else if (ext === 'docx' || ext === 'xlsx') type = 'Office Open XML Document';
    return {
      detectedType: type,
      magicHex: hex,
      isMismatch: false,
      category: 'archives',
    };
  }

  if (bytes[0] === 0x25 && bytes[1] === 0x50 && bytes[2] === 0x44 && bytes[3] === 0x46) {
    return {
      detectedType: 'PDF Document (%PDF)',
      magicHex: hex,
      isMismatch: ext !== 'pdf',
      category: 'documents',
    };
  }

  if (bytes[0] === 0x89 && bytes[1] === 0x50 && bytes[2] === 0x4e && bytes[3] === 0x47) {
    return {
      detectedType: 'PNG Image',
      magicHex: hex,
      isMismatch: ext !== 'png',
      category: 'media',
    };
  }

  if (bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff) {
    return {
      detectedType: 'JPEG Image',
      magicHex: hex,
      isMismatch: ext !== 'jpg' && ext !== 'jpeg',
      category: 'media',
    };
  }

  if (bytes[0] === 0x37 && bytes[1] === 0x7a && bytes[2] === 0xbc && bytes[3] === 0xaf) {
    return {
      detectedType: '7-Zip Compressed Archive',
      magicHex: hex,
      isMismatch: ext !== '7z',
      category: 'archives',
    };
  }

  if (bytes[0] === 0x1f && bytes[1] === 0x8b) {
    return {
      detectedType: 'GZIP Compressed Data',
      magicHex: hex,
      isMismatch: ext !== 'gz' && ext !== 'tgz',
      category: 'archives',
    };
  }

  if (bytes[0] === 0x23 && bytes[1] === 0x21) {
    return {
      detectedType: 'Unix Script (Shebang #!)',
      magicHex: hex,
      isMismatch: false,
      category: 'scripts',
    };
  }

  // Fallback check by extension
  if (['ps1', 'bat', 'cmd', 'vbs', 'sh', 'py', 'js', 'bash'].includes(ext)) {
    return {
      detectedType: `${ext.toUpperCase()} Script`,
      magicHex: hex,
      isMismatch: false,
      category: 'scripts',
    };
  }

  if (['json', 'xml', 'yaml', 'yml', 'md', 'txt', 'csv', 'sql'].includes(ext)) {
    return {
      detectedType: `${ext.toUpperCase()} Text Document`,
      magicHex: hex,
      isMismatch: false,
      category: 'documents',
    };
  }

  return {
    detectedType: 'Generic Binary / Data Stream',
    magicHex: hex,
    isMismatch: false,
    category: 'all',
  };
}
