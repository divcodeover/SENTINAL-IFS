import { CyberFile, RiskIndicator, RiskLevel } from '../types';
import {
  calculateMD5,
  calculateShannonEntropy,
  calculateWebCryptoHash,
  detectMagicBytes,
  extractStrings,
} from './crypto';

export async function analyzeBrowserFile(
  file: File,
  folderId = 'downloads',
  customPath = '/Downloads'
): Promise<CyberFile> {
  const buffer = await file.arrayBuffer();
  const bytes = new Uint8Array(buffer);
  const size = file.size;
  const name = file.name;
  const extension = name.includes('.') ? name.split('.').pop()!.toLowerCase() : '';
  const mimeType = file.type || 'application/octet-stream';
  const modifiedAt = new Date(file.lastModified).toISOString();
  const createdAt = new Date().toISOString();

  // 1. Calculate Hashes
  const sha256 = await calculateWebCryptoHash(buffer, 'SHA-256');
  const sha1 = await calculateWebCryptoHash(buffer, 'SHA-1');
  const md5 = calculateMD5(bytes);

  // 2. Entropy Analysis
  const { entropy, byteDistribution, interpretation } = calculateShannonEntropy(bytes);

  // 3. Magic Bytes Detection
  const { detectedType, magicHex, isMismatch } = detectMagicBytes(bytes, name);

  // 4. Extract Strings
  const extractedStrings = extractStrings(bytes, 4, 300);

  // 5. Hex Sample (first 1024 bytes)
  const hexSample = Array.from(bytes.slice(0, Math.min(1024, bytes.length)));

  // 6. Safe Text Preview if applicable
  let textContent: string | undefined;
  const isTextLike =
    mimeType.startsWith('text/') ||
    ['json', 'xml', 'yaml', 'yml', 'md', 'txt', 'csv', 'sql', 'sh', 'bat', 'ps1', 'js', 'ts', 'html', 'css', 'py'].includes(
      extension
    );

  if (isTextLike && bytes.length < 500 * 1024) {
    try {
      const decoder = new TextDecoder('utf-8', { fatal: false });
      textContent = decoder.decode(bytes.slice(0, 32 * 1024));
    } catch {
      textContent = undefined;
    }
  }

  // 7. Assess Risk and Construct Indicators
  const riskIndicators: RiskIndicator[] = [];
  let riskScore = 10; // Baseline

  const lowerName = name.toLowerCase();

  // Double extension detection (e.g. invoice.pdf.exe)
  const dotParts = name.split('.');
  if (dotParts.length > 2) {
    const secondLast = dotParts[dotParts.length - 2].toLowerCase();
    const dangerousLast = ['exe', 'scr', 'bat', 'vbs', 'ps1', 'cmd', 'pif', 'com'];
    if (dangerousLast.includes(extension) && ['pdf', 'docx', 'xlsx', 'jpg', 'png', 'txt'].includes(secondLast)) {
      riskScore += 45;
      riskIndicators.push({
        id: 'double-ext',
        level: 'danger',
        title: 'Masquerading Double Extension',
        description: `Filename "${name}" disguises an executable payload as a ${secondLast.toUpperCase()} document.`,
      });
    }
  }

  // Dangerous / executable extension
  const executableExts = ['exe', 'dll', 'sys', 'bat', 'cmd', 'ps1', 'vbs', 'js', 'wsf', 'apk', 'elf', 'scr', 'msi'];
  if (executableExts.includes(extension)) {
    riskScore += 25;
    riskIndicators.push({
      id: 'executable-type',
      level: 'warning',
      title: 'Untrusted Binary / Script Extension',
      description: `File carries executable extension (.${extension}). Isolated in zero-execution sandbox.`,
    });
  }

  // Magic byte mismatch
  if (isMismatch) {
    riskScore += 35;
    riskIndicators.push({
      id: 'magic-mismatch',
      level: 'danger',
      title: 'File Signature / Header Mismatch',
      description: `File extension .${extension} does not match actual binary header (${detectedType}). Potential payload disguise.`,
    });
  }

  // High entropy indicating packing or encryption
  if (entropy >= 7.2) {
    riskScore += 25;
    riskIndicators.push({
      id: 'high-entropy',
      level: 'warning',
      title: 'High Shannon Entropy (> 7.2)',
      description: `Entropy is ${entropy.toFixed(2)}/8.00. Indicates compressed, encrypted, or packed binary code common in obfuscated malware.`,
    });
  }

  // Suspicious extracted strings
  const suspiciousStrings = extractedStrings.filter(s => s.isSuspicious);
  if (suspiciousStrings.length > 0) {
    const dangerousCount = suspiciousStrings.length;
    riskScore += Math.min(30, dangerousCount * 6);
    riskIndicators.push({
      id: 'suspicious-strings',
      level: dangerousCount > 3 ? 'danger' : 'warning',
      title: `Suspicious API / Command Artifacts (${dangerousCount})`,
      description: `Found embedded references to system execution, command shells, or network endpoints (${suspiciousStrings.slice(0, 3).map(s => s.str).join(', ')}).`,
    });
  }

  // Safe file indicator if low score
  if (riskIndicators.length === 0) {
    riskIndicators.push({
      id: 'clean-signature',
      level: 'info',
      title: 'No Anomalies Detected',
      description: 'Standard file structure, normal entropy distribution, and benign content signature.',
    });
  }

  riskScore = Math.min(100, Math.max(0, riskScore));

  let riskLevel: RiskLevel = 'clean';
  if (riskScore >= 75) riskLevel = 'critical';
  else if (riskScore >= 50) riskLevel = 'high';
  else if (riskScore >= 25) riskLevel = 'medium';
  else if (riskScore > 15) riskLevel = 'low';

  const isUntrusted = riskLevel === 'high' || riskLevel === 'critical' || executableExts.includes(extension);

  return {
    id: `file_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`,
    name,
    path: `${customPath}/${name}`,
    folderId,
    size,
    extension,
    mimeType,
    createdAt,
    modifiedAt,
    sha256,
    sha1,
    md5,
    entropy,
    entropyInterpretation: interpretation,
    byteDistribution,
    magicBytes: magicHex,
    detectedType,
    isUntrusted,
    riskLevel,
    riskScore,
    riskIndicators,
    permissions: {
      read: true,
      write: false,
      execute: false, // ZERO-EXECUTION ENFORCED
      quarantine: isUntrusted,
    },
    isFavorite: false,
    isTrash: false,
    extractedStrings,
    hexSample,
    textContent,
  };
}

export function formatBytes(bytes: number, decimals = 1): string {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(dm))} ${sizes[i]}`;
}

export function truncateHash(hash: string, start = 8, end = 8): string {
  if (!hash || hash.length <= start + end) return hash;
  return `${hash.slice(0, start)}...${hash.slice(-end)}`;
}
