import React from 'react';
import {
  FileText,
  FileCode,
  Binary,
  Archive,
  Image,
  ShieldAlert,
  ShieldCheck,
  AlertTriangle,
  Lock,
  Star,
  Copy,
  Check,
  Eye,
} from 'lucide-react';
import { CyberFile } from '../types';
import { formatBytes, truncateHash } from '../utils/fileAnalyzer';

interface FileRowProps {
  file: CyberFile;
  isSelected: boolean;
  onSelect: (e: React.MouseEvent, file: CyberFile) => void;
  onContextMenu: (e: React.MouseEvent, file: CyberFile) => void;
  onDoubleClick: (file: CyberFile) => void;
}

export const FileRow: React.FC<FileRowProps> = ({
  file,
  isSelected,
  onSelect,
  onContextMenu,
  onDoubleClick,
}) => {
  const [copied, setCopied] = React.useState(false);

  const getFileIcon = () => {
    const ext = file.extension.toLowerCase();
    if (['exe', 'dll', 'sys', 'bin', 'elf', 'scr'].includes(ext)) {
      return <Binary className="h-4 w-4 text-purple-700" />;
    }
    if (['ps1', 'sh', 'bat', 'vbs', 'js', 'py'].includes(ext)) {
      return <FileCode className="h-4 w-4 text-indigo-600" />;
    }
    if (['zip', 'rar', '7z', 'tar', 'gz', 'apk'].includes(ext)) {
      return <Archive className="h-4 w-4 text-amber-600" />;
    }
    if (['png', 'jpg', 'jpeg', 'gif', 'svg'].includes(ext)) {
      return <Image className="h-4 w-4 text-cyan-600" />;
    }
    return <FileText className="h-4 w-4 text-slate-600" />;
  };

  const getRiskBadge = () => {
    switch (file.riskLevel) {
      case 'critical':
        return (
          <span className="inline-flex items-center gap-1 rounded bg-rose-100 px-1.5 py-0.5 text-[10px] font-bold text-rose-800 border border-rose-200">
            <ShieldAlert className="h-2.5 w-2.5" /> CRITICAL
          </span>
        );
      case 'high':
        return (
          <span className="inline-flex items-center gap-1 rounded bg-amber-100 px-1.5 py-0.5 text-[10px] font-bold text-amber-800 border border-amber-200">
            <AlertTriangle className="h-2.5 w-2.5" /> HIGH
          </span>
        );
      case 'medium':
        return (
          <span className="inline-flex items-center gap-1 rounded bg-yellow-100 px-1.5 py-0.5 text-[10px] font-medium text-yellow-800 border border-yellow-200">
            MEDIUM
          </span>
        );
      case 'low':
        return (
          <span className="inline-flex items-center gap-1 rounded bg-blue-50 px-1.5 py-0.5 text-[10px] font-medium text-blue-700 border border-blue-200">
            LOW
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 rounded bg-emerald-50 px-1.5 py-0.5 text-[10px] font-medium text-emerald-700 border border-emerald-200">
            <ShieldCheck className="h-2.5 w-2.5" /> BENIGN
          </span>
        );
    }
  };

  const handleCopyHash = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(file.sha256);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  return (
    <tr
      id={`file-row-${file.id}`}
      onClick={e => onSelect(e, file)}
      onDoubleClick={() => onDoubleClick(file)}
      onContextMenu={e => onContextMenu(e, file)}
      className={`border-b border-slate-100 text-xs transition-colors cursor-pointer select-none ${
        isSelected
          ? 'bg-purple-50/80 font-medium text-purple-950'
          : 'hover:bg-slate-50 text-slate-700'
      }`}
    >
      {/* Selection checkbox & Icon & Name */}
      <td className="py-2.5 pl-4 pr-2">
        <div className="flex items-center gap-2.5 max-w-sm">
          <div className="shrink-0">{getFileIcon()}</div>
          <span className="truncate font-semibold text-slate-900" title={file.name}>
            {file.name}
          </span>
          {file.permissions.quarantine && (
            <span
              className="shrink-0 rounded bg-slate-900 px-1 py-0.2 text-[9px] font-bold text-white uppercase"
              title="Quarantined"
            >
              Locked
            </span>
          )}
          {file.isFavorite && (
            <Star className="h-3 w-3 text-amber-500 fill-amber-400 shrink-0" />
          )}
        </div>
      </td>

      {/* Detected Type */}
      <td className="py-2.5 px-3 text-slate-500 truncate max-w-[180px]">
        {file.detectedType}
      </td>

      {/* File Size */}
      <td className="py-2.5 px-3 font-mono text-slate-600 whitespace-nowrap">
        {formatBytes(file.size)}
      </td>

      {/* Shannon Entropy */}
      <td className="py-2.5 px-3 whitespace-nowrap">
        <span
          className={`font-mono text-[11px] px-1.5 py-0.5 rounded font-medium ${
            file.entropy >= 7.2
              ? 'bg-rose-50 text-rose-700 font-bold'
              : file.entropy >= 5.0
              ? 'bg-purple-50 text-purple-800'
              : 'bg-slate-100 text-slate-700'
          }`}
        >
          {file.entropy.toFixed(2)}
        </span>
      </td>

      {/* Risk Badge */}
      <td className="py-2.5 px-3 whitespace-nowrap">{getRiskBadge()}</td>

      {/* SHA-256 Hash with quick copy */}
      <td className="py-2.5 px-3 font-mono text-[11px] text-slate-500 whitespace-nowrap">
        <div className="flex items-center gap-1.5">
          <span>{truncateHash(file.sha256, 6, 6)}</span>
          <button
            onClick={handleCopyHash}
            className="text-slate-400 hover:text-purple-700 transition-colors p-0.5"
            title="Copy full SHA-256 hash"
          >
            {copied ? (
              <Check className="h-3 w-3 text-emerald-600" />
            ) : (
              <Copy className="h-3 w-3" />
            )}
          </button>
        </div>
      </td>

      {/* Modified Date */}
      <td className="py-2.5 pl-3 pr-4 text-slate-500 whitespace-nowrap text-right font-mono text-[11px]">
        {new Date(file.modifiedAt).toLocaleDateString()}
      </td>
    </tr>
  );
};
