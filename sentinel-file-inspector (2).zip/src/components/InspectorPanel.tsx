import React, { useState } from 'react';
import {
  X,
  Shield,
  ShieldAlert,
  ShieldCheck,
  Hash,
  Activity,
  Binary,
  FileCode,
  Lock,
  Copy,
  Check,
  AlertTriangle,
  FileText,
  Calendar,
  HardDrive,
  Cpu,
  ExternalLink,
  Search,
  Filter,
  Eye,
  SlidersHorizontal,
} from 'lucide-react';
import { CyberFile } from '../types';
import { formatBytes } from '../utils/fileAnalyzer';
import { EntropyGauge } from './EntropyGauge';
import { HexViewer } from './HexViewer';

interface InspectorPanelProps {
  file: CyberFile | null;
  onClose: () => void;
  onToggleQuarantine: (fileId: string) => void;
  onToggleFavorite: (fileId: string) => void;
  onOpenDiff: (file: CyberFile) => void;
}

type InspectorTab = 'overview' | 'hashes' | 'entropy' | 'strings' | 'hex' | 'preview';

export const InspectorPanel: React.FC<InspectorPanelProps> = ({
  file,
  onClose,
  onToggleQuarantine,
  onToggleFavorite,
  onOpenDiff,
}) => {
  const [activeTab, setActiveTab] = useState<InspectorTab>('overview');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [verifyHashInput, setVerifyHashInput] = useState('');
  const [stringSearch, setStringSearch] = useState('');
  const [stringCategoryFilter, setStringCategoryFilter] = useState<string>('all');

  if (!file) {
    return (
      <aside
        id="inspector-empty-panel"
        className="w-96 border-l border-slate-200 bg-white p-6 flex flex-col items-center justify-center text-center select-none"
      >
        <div className="flex h-14 w-14 items-center justify-center rounded-xl bg-purple-50 text-purple-600 border border-purple-100 mb-4">
          <Shield className="h-7 w-7" />
        </div>
        <h3 className="text-sm font-semibold text-slate-800 mb-1">Static Security Inspector</h3>
        <p className="text-xs text-slate-500 max-w-xs leading-relaxed">
          Select any ingested file or folder to calculate cryptographic hashes, inspect binary entropy, extract suspicious strings, and review static risk indicators.
        </p>
        <div className="mt-6 flex items-center gap-1.5 rounded-full bg-slate-100 px-3 py-1 text-[11px] font-mono text-slate-600">
          <Lock className="h-3 w-3 text-purple-700" />
          <span>Zero-Execution Guard Active</span>
        </div>
      </aside>
    );
  }

  const handleCopy = (key: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const getRiskBadge = (level: string) => {
    switch (level) {
      case 'critical':
        return {
          badge: 'bg-rose-100 text-rose-800 border-rose-200',
          icon: ShieldAlert,
          label: 'CRITICAL RISK',
        };
      case 'high':
        return {
          badge: 'bg-amber-100 text-amber-900 border-amber-200',
          icon: AlertTriangle,
          label: 'HIGH RISK',
        };
      case 'medium':
        return {
          badge: 'bg-yellow-100 text-yellow-800 border-yellow-200',
          icon: AlertTriangle,
          label: 'MEDIUM RISK',
        };
      case 'low':
        return {
          badge: 'bg-blue-100 text-blue-800 border-blue-200',
          icon: Shield,
          label: 'LOW RISK',
        };
      default:
        return {
          badge: 'bg-emerald-100 text-emerald-800 border-emerald-200',
          icon: ShieldCheck,
          label: 'VERIFIED BENIGN',
        };
    }
  };

  const riskBadge = getRiskBadge(file.riskLevel);
  const RiskIcon = riskBadge.icon;

  // Filter extracted strings
  const filteredStrings = file.extractedStrings.filter(s => {
    const matchesSearch = s.str.toLowerCase().includes(stringSearch.toLowerCase());
    const matchesCat =
      stringCategoryFilter === 'all' ||
      (stringCategoryFilter === 'suspicious' && s.isSuspicious) ||
      s.category === stringCategoryFilter;
    return matchesSearch && matchesCat;
  });

  // Verify pasted hash comparison
  const normalizedVerifyInput = verifyHashInput.trim().toLowerCase();
  const isHashMatch =
    normalizedVerifyInput.length > 0 &&
    (normalizedVerifyInput === file.sha256.toLowerCase() ||
      normalizedVerifyInput === file.sha1.toLowerCase() ||
      normalizedVerifyInput === file.md5.toLowerCase());

  const isHashMismatch =
    normalizedVerifyInput.length >= 32 && !isHashMatch;

  return (
    <aside
      id="security-inspector-panel"
      className="w-96 md:w-[440px] border-l border-slate-200 bg-white flex flex-col h-full overflow-hidden shadow-xs z-20 select-text"
    >
      {/* Inspector Header */}
      <div className="border-b border-slate-200 bg-[#FAF9FD] p-4">
        <div className="flex items-start justify-between gap-2">
          <div className="flex items-center gap-2 overflow-hidden">
            <span
              className={`inline-flex items-center gap-1 rounded-md px-2 py-0.5 text-[11px] font-bold tracking-wider border ${riskBadge.badge}`}
            >
              <RiskIcon className="h-3 w-3" />
              {riskBadge.label}
            </span>

            {file.permissions.quarantine && (
              <span className="rounded bg-slate-900 px-1.5 py-0.5 text-[10px] font-semibold tracking-wider text-white">
                QUARANTINED
              </span>
            )}
          </div>

          <div className="flex items-center gap-1">
            <button
              onClick={() => onOpenDiff(file)}
              className="rounded p-1 text-slate-500 hover:bg-slate-200 hover:text-slate-800 transition-colors"
              title="Compare with another file"
            >
              <SlidersHorizontal className="h-4 w-4" />
            </button>
            <button
              onClick={onClose}
              className="rounded p-1 text-slate-500 hover:bg-slate-200 hover:text-slate-800 transition-colors"
              title="Close inspection panel"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* File Title and Quick stats */}
        <div className="mt-2">
          <h2 className="text-sm font-bold text-slate-900 break-all leading-snug">
            {file.name}
          </h2>
          <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-500">
            <span className="font-mono">{formatBytes(file.size)}</span>
            <span>•</span>
            <span className="truncate max-w-[200px]">{file.detectedType}</span>
            <span>•</span>
            <span className="font-mono uppercase text-[11px]">.{file.extension || 'BIN'}</span>
          </div>
        </div>

        {/* Actions bar */}
        <div className="mt-3 flex items-center gap-2">
          <button
            onClick={() => onToggleQuarantine(file.id)}
            className={`flex-1 flex items-center justify-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-semibold border transition-all ${
              file.permissions.quarantine
                ? 'bg-amber-50 border-amber-300 text-amber-900 hover:bg-amber-100'
                : 'bg-purple-900 border-purple-950 text-white hover:bg-purple-800 shadow-xs'
            }`}
          >
            <Lock className="h-3.5 w-3.5" />
            <span>{file.permissions.quarantine ? 'Release from Quarantine' : 'Isolate / Quarantine'}</span>
          </button>

          <button
            onClick={() => onToggleFavorite(file.id)}
            className={`rounded-md border p-1.5 text-xs transition-colors ${
              file.isFavorite
                ? 'bg-amber-50 border-amber-300 text-amber-600'
                : 'bg-white border-slate-300 text-slate-600 hover:bg-slate-50'
            }`}
            title="Toggle Bookmark"
          >
            ★
          </button>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex border-b border-slate-200 bg-white px-2 overflow-x-auto text-xs font-medium">
        <button
          onClick={() => setActiveTab('overview')}
          className={`flex items-center gap-1.5 px-3 py-2 border-b-2 transition-colors whitespace-nowrap ${
            activeTab === 'overview'
              ? 'border-purple-700 text-purple-900 font-semibold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Shield className="h-3.5 w-3.5" />
          Overview
        </button>

        <button
          onClick={() => setActiveTab('hashes')}
          className={`flex items-center gap-1.5 px-3 py-2 border-b-2 transition-colors whitespace-nowrap ${
            activeTab === 'hashes'
              ? 'border-purple-700 text-purple-900 font-semibold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Hash className="h-3.5 w-3.5" />
          Hashes
        </button>

        <button
          onClick={() => setActiveTab('entropy')}
          className={`flex items-center gap-1.5 px-3 py-2 border-b-2 transition-colors whitespace-nowrap ${
            activeTab === 'entropy'
              ? 'border-purple-700 text-purple-900 font-semibold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Activity className="h-3.5 w-3.5" />
          Entropy ({file.entropy.toFixed(1)})
        </button>

        <button
          onClick={() => setActiveTab('strings')}
          className={`flex items-center gap-1.5 px-3 py-2 border-b-2 transition-colors whitespace-nowrap ${
            activeTab === 'strings'
              ? 'border-purple-700 text-purple-900 font-semibold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <FileCode className="h-3.5 w-3.5" />
          Strings ({file.extractedStrings.length})
        </button>

        <button
          onClick={() => setActiveTab('hex')}
          className={`flex items-center gap-1.5 px-3 py-2 border-b-2 transition-colors whitespace-nowrap ${
            activeTab === 'hex'
              ? 'border-purple-700 text-purple-900 font-semibold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Binary className="h-3.5 w-3.5" />
          Hex
        </button>

        {file.textContent && (
          <button
            onClick={() => setActiveTab('preview')}
            className={`flex items-center gap-1.5 px-3 py-2 border-b-2 transition-colors whitespace-nowrap ${
              activeTab === 'preview'
                ? 'border-purple-700 text-purple-900 font-semibold'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Eye className="h-3.5 w-3.5" />
            Preview
          </button>
        )}
      </div>

      {/* Tab Contents */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {/* OVERVIEW TAB */}
        {activeTab === 'overview' && (
          <div className="space-y-4">
            {/* Risk Assessment Score Card */}
            <div className="rounded-lg border border-purple-100 bg-purple-50/50 p-3.5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold uppercase tracking-wider text-purple-900">
                  Static Risk Rating
                </span>
                <span className="font-mono text-sm font-bold text-purple-950">
                  {file.riskScore} / 100
                </span>
              </div>
              <div className="mt-2 h-1.5 w-full rounded-full bg-purple-200 overflow-hidden">
                <div
                  className={`h-full transition-all ${
                    file.riskScore >= 75
                      ? 'bg-rose-600'
                      : file.riskScore >= 45
                      ? 'bg-amber-500'
                      : 'bg-emerald-600'
                  }`}
                  style={{ width: `${file.riskScore}%` }}
                />
              </div>

              {/* Zero execution disclaimer */}
              <div className="mt-2.5 flex items-center gap-1 text-[11px] text-purple-800 font-medium">
                <Lock className="h-3 w-3" />
                <span>Zero Execution Mandate: File is handled as static untrusted bytes.</span>
              </div>
            </div>

            {/* Risk Indicators List */}
            <div className="space-y-2">
              <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                Threat & Structural Indicators
              </h4>
              {file.riskIndicators.map((ind, idx) => (
                <div
                  key={idx}
                  className={`rounded-md border p-2.5 text-xs ${
                    ind.level === 'danger'
                      ? 'border-rose-200 bg-rose-50/70 text-rose-900'
                      : ind.level === 'warning'
                      ? 'border-amber-200 bg-amber-50/70 text-amber-900'
                      : 'border-slate-200 bg-slate-50 text-slate-800'
                  }`}
                >
                  <div className="flex items-center gap-1.5 font-bold">
                    {ind.level === 'danger' ? (
                      <ShieldAlert className="h-3.5 w-3.5 text-rose-600 shrink-0" />
                    ) : ind.level === 'warning' ? (
                      <AlertTriangle className="h-3.5 w-3.5 text-amber-600 shrink-0" />
                    ) : (
                      <ShieldCheck className="h-3.5 w-3.5 text-emerald-600 shrink-0" />
                    )}
                    <span>{ind.title}</span>
                  </div>
                  <p className="mt-1 text-[11px] opacity-90 leading-relaxed">{ind.description}</p>
                </div>
              ))}
            </div>

            {/* File Metadata Details */}
            <div className="space-y-2">
              <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                File System Metadata
              </h4>
              <div className="divide-y divide-slate-100 rounded-lg border border-slate-200 bg-white text-xs">
                <div className="flex justify-between p-2.5">
                  <span className="text-slate-500">Storage Size</span>
                  <span className="font-mono font-medium text-slate-900">
                    {file.size.toLocaleString()} bytes ({formatBytes(file.size)})
                  </span>
                </div>
                <div className="flex justify-between p-2.5">
                  <span className="text-slate-500">MIME Type</span>
                  <span className="font-mono text-slate-800">{file.mimeType}</span>
                </div>
                <div className="flex justify-between p-2.5">
                  <span className="text-slate-500">Magic Bytes Signature</span>
                  <span className="font-mono text-purple-900 font-semibold">{file.magicBytes}</span>
                </div>
                <div className="flex justify-between p-2.5">
                  <span className="text-slate-500">Virtual Location</span>
                  <span className="font-mono text-slate-800">{file.path}</span>
                </div>
                <div className="flex justify-between p-2.5">
                  <span className="text-slate-500">Modified Date</span>
                  <span className="font-mono text-slate-800">
                    {new Date(file.modifiedAt).toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between p-2.5">
                  <span className="text-slate-500">Execution Permissions</span>
                  <span className="inline-flex items-center gap-1 text-emerald-700 font-semibold font-mono">
                    <Check className="h-3 w-3" /> Blocked (Read Only)
                  </span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* HASHES TAB */}
        {activeTab === 'hashes' && (
          <div className="space-y-4">
            {/* Hash Verification Input */}
            <div className="rounded-lg border border-slate-200 bg-slate-50 p-3 space-y-2">
              <label className="text-xs font-semibold text-slate-700 flex items-center justify-between">
                <span>Integrity / IOC Hash Lookup</span>
                {isHashMatch && (
                  <span className="text-emerald-700 font-bold text-[11px] flex items-center gap-1">
                    <Check className="h-3 w-3" /> MATCH CONFIRMED
                  </span>
                )}
                {isHashMismatch && (
                  <span className="text-rose-600 font-bold text-[11px] flex items-center gap-1">
                    <X className="h-3 w-3" /> MISMATCH DETECTED
                  </span>
                )}
              </label>
              <input
                type="text"
                value={verifyHashInput}
                onChange={e => setVerifyHashInput(e.target.value)}
                placeholder="Paste expected SHA-256, SHA-1, or MD5 to verify..."
                className={`w-full rounded border px-2.5 py-1.5 text-xs font-mono transition-colors focus:outline-none ${
                  isHashMatch
                    ? 'border-emerald-500 bg-emerald-50/50'
                    : isHashMismatch
                    ? 'border-rose-400 bg-rose-50/50'
                    : 'border-slate-300 bg-white focus:border-purple-600'
                }`}
              />
              <p className="text-[11px] text-slate-500">
                Instant cryptographic integrity check against threat intelligence or release digests.
              </p>
            </div>

            {/* Hashes List */}
            <div className="space-y-3">
              {/* SHA-256 */}
              <div className="rounded-lg border border-slate-200 bg-white p-3 space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-700">SHA-256</span>
                  <button
                    onClick={() => handleCopy('sha256', file.sha256)}
                    className="flex items-center gap-1 text-[11px] font-medium text-purple-700 hover:text-purple-900 transition-colors"
                  >
                    {copiedKey === 'sha256' ? (
                      <>
                        <Check className="h-3 w-3 text-emerald-600" />
                        <span>Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="h-3 w-3" />
                        <span>Copy</span>
                      </>
                    )}
                  </button>
                </div>
                <div className="rounded bg-slate-50 p-2 font-mono text-[11px] text-slate-900 break-all border border-slate-200 select-all">
                  {file.sha256}
                </div>
              </div>

              {/* SHA-1 */}
              <div className="rounded-lg border border-slate-200 bg-white p-3 space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-700">SHA-1</span>
                  <button
                    onClick={() => handleCopy('sha1', file.sha1)}
                    className="flex items-center gap-1 text-[11px] font-medium text-purple-700 hover:text-purple-900 transition-colors"
                  >
                    {copiedKey === 'sha1' ? (
                      <>
                        <Check className="h-3 w-3 text-emerald-600" />
                        <span>Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="h-3 w-3" />
                        <span>Copy</span>
                      </>
                    )}
                  </button>
                </div>
                <div className="rounded bg-slate-50 p-2 font-mono text-[11px] text-slate-900 break-all border border-slate-200 select-all">
                  {file.sha1}
                </div>
              </div>

              {/* MD5 */}
              <div className="rounded-lg border border-slate-200 bg-white p-3 space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-700">MD5</span>
                  <button
                    onClick={() => handleCopy('md5', file.md5)}
                    className="flex items-center gap-1 text-[11px] font-medium text-purple-700 hover:text-purple-900 transition-colors"
                  >
                    {copiedKey === 'md5' ? (
                      <>
                        <Check className="h-3 w-3 text-emerald-600" />
                        <span>Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="h-3 w-3" />
                        <span>Copy</span>
                      </>
                    )}
                  </button>
                </div>
                <div className="rounded bg-slate-50 p-2 font-mono text-[11px] text-slate-900 break-all border border-slate-200 select-all">
                  {file.md5}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ENTROPY TAB */}
        {activeTab === 'entropy' && (
          <EntropyGauge
            entropy={file.entropy}
            distribution={file.byteDistribution}
            interpretation={file.entropyInterpretation}
          />
        )}

        {/* STRINGS TAB */}
        {activeTab === 'strings' && (
          <div className="space-y-3">
            {/* Filter toolbar */}
            <div className="space-y-2">
              <div className="relative">
                <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-slate-400" />
                <input
                  type="text"
                  placeholder="Filter extracted strings..."
                  value={stringSearch}
                  onChange={e => setStringSearch(e.target.value)}
                  className="w-full rounded border border-slate-300 pl-8 pr-2.5 py-1.5 text-xs focus:border-purple-600 focus:outline-none"
                />
              </div>

              <div className="flex flex-wrap gap-1 text-[11px]">
                {['all', 'suspicious', 'network', 'execution', 'registry', 'cryptography'].map(cat => (
                  <button
                    key={cat}
                    onClick={() => setStringCategoryFilter(cat)}
                    className={`rounded px-2 py-0.5 capitalize transition-colors ${
                      stringCategoryFilter === cat
                        ? 'bg-purple-900 text-white font-medium'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            {/* Strings list */}
            <div className="rounded-lg border border-slate-200 bg-[#FAF9FD] p-2 max-h-[380px] overflow-y-auto divide-y divide-slate-100 font-mono text-xs">
              {filteredStrings.length === 0 ? (
                <div className="py-8 text-center text-xs text-slate-400">
                  No matching strings identified in sample
                </div>
              ) : (
                filteredStrings.map((item, idx) => (
                  <div
                    key={idx}
                    className={`py-1.5 px-1.5 flex items-start justify-between gap-2 hover:bg-white rounded transition-colors ${
                      item.isSuspicious ? 'bg-rose-50/60 text-rose-950 font-medium' : 'text-slate-800'
                    }`}
                  >
                    <div className="overflow-hidden break-all">
                      <span className="text-[10px] text-slate-400 mr-2 select-none">
                        +0x{item.offset.toString(16).toUpperCase()}
                      </span>
                      <span>{item.str}</span>
                    </div>

                    {item.isSuspicious && (
                      <span className="shrink-0 rounded bg-rose-200 px-1 py-0.2 text-[9px] font-bold text-rose-800 uppercase">
                        {item.category || 'IOC'}
                      </span>
                    )}
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* HEX TAB */}
        {activeTab === 'hex' && (
          <div className="h-[420px]">
            <HexViewer bytes={file.hexSample} filename={file.name} />
          </div>
        )}

        {/* PREVIEW TAB */}
        {activeTab === 'preview' && file.textContent && (
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs text-slate-500">
              <span>Sanitized Text Preview (Read-Only)</span>
              <button
                onClick={() => handleCopy('text', file.textContent || '')}
                className="text-purple-700 hover:underline text-[11px]"
              >
                Copy Content
              </button>
            </div>
            <pre className="max-h-[420px] overflow-auto rounded-lg border border-slate-200 bg-slate-50 p-3 font-mono text-xs text-slate-800 whitespace-pre-wrap select-text leading-relaxed">
              {file.textContent}
            </pre>
          </div>
        )}
      </div>
    </aside>
  );
};
