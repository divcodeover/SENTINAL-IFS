import React, { useState, useMemo } from 'react';
import {
  Upload,
  FolderOpen,
  Filter,
  CheckSquare,
  Square,
  Lock,
  Trash2,
  Copy,
  Check,
  ShieldAlert,
  ArrowRight,
} from 'lucide-react';
import { CyberFile, CategoryFilter, ViewMode } from '../types';
import { FileCard } from './FileCard';
import { FileRow } from './FileRow';
import { formatBytes } from '../utils/fileAnalyzer';

interface FileBrowserProps {
  files: CyberFile[];
  currentFolderTitle: string;
  currentFolderId: string;
  selectedFileIds: Set<string>;
  onToggleSelect: (e: React.MouseEvent, file: CyberFile) => void;
  onSelectAll: () => void;
  onClearSelection: () => void;
  onInspectFile: (file: CyberFile) => void;
  onContextMenu: (e: React.MouseEvent, file: CyberFile) => void;
  onBatchQuarantine: () => void;
  onBatchDelete: () => void;
  onFilesDropped: (files: FileList | File[]) => void;
  onImportClick: () => void;
  categoryFilter: CategoryFilter;
  onCategoryFilterChange: (cat: CategoryFilter) => void;
  viewMode: ViewMode;
}

export const FileBrowser: React.FC<FileBrowserProps> = ({
  files,
  currentFolderTitle,
  currentFolderId,
  selectedFileIds,
  onToggleSelect,
  onSelectAll,
  onClearSelection,
  onInspectFile,
  onContextMenu,
  onBatchQuarantine,
  onBatchDelete,
  onFilesDropped,
  onImportClick,
  categoryFilter,
  onCategoryFilterChange,
  viewMode,
}) => {
  const [isDragOver, setIsDragOver] = useState(false);
  const [copiedBatch, setCopiedBatch] = useState(false);

  // Drag & drop handlers
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    // Only turn off if leaving browser boundary
    if (e.currentTarget.contains(e.relatedTarget as Node)) return;
    setIsDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(false);

    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      onFilesDropped(e.dataTransfer.files);
    }
  };

  // Filter files by category
  const filteredFiles = useMemo(() => {
    return files.filter(f => {
      if (categoryFilter === 'all') return true;
      if (categoryFilter === 'high_risk') return f.riskLevel === 'high' || f.riskLevel === 'critical';
      if (categoryFilter === 'quarantined') return f.permissions.quarantine;

      const ext = f.extension.toLowerCase();
      if (categoryFilter === 'executables') return ['exe', 'dll', 'sys', 'bin', 'elf', 'scr'].includes(ext);
      if (categoryFilter === 'scripts') return ['ps1', 'sh', 'bat', 'vbs', 'js', 'py'].includes(ext);
      if (categoryFilter === 'archives') return ['zip', 'rar', '7z', 'tar', 'gz', 'apk'].includes(ext);
      if (categoryFilter === 'documents') return ['pdf', 'docx', 'xlsx', 'txt', 'json', 'xml', 'md', 'sql'].includes(ext);
      if (categoryFilter === 'media') return ['png', 'jpg', 'jpeg', 'gif', 'svg', 'mp4', 'wav'].includes(ext);
      return true;
    });
  }, [files, categoryFilter]);

  const allSelected = filteredFiles.length > 0 && filteredFiles.every(f => selectedFileIds.has(f.id));

  // Batch copy selected hashes
  const handleBatchCopyHashes = () => {
    const selectedFiles = files.filter(f => selectedFileIds.has(f.id));
    const manifest = selectedFiles
      .map(f => `${f.sha256}  ${f.name}  (MD5: ${f.md5})`)
      .join('\n');
    navigator.clipboard.writeText(manifest);
    setCopiedBatch(true);
    setTimeout(() => setCopiedBatch(false), 2000);
  };

  const categories: Array<{ id: CategoryFilter; label: string }> = [
    { id: 'all', label: 'All Artifacts' },
    { id: 'executables', label: 'Executables' },
    { id: 'scripts', label: 'Scripts' },
    { id: 'archives', label: 'Archives' },
    { id: 'documents', label: 'Documents' },
    { id: 'high_risk', label: 'High Risk' },
    { id: 'quarantined', label: 'Quarantined' },
  ];

  return (
    <div
      id="file-browser-container"
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
      className="relative flex-1 flex flex-col h-full bg-[#FCFBFE] overflow-hidden select-none"
    >
      {/* Drop Zone Overlay */}
      {isDragOver && (
        <div className="absolute inset-0 z-50 flex flex-col items-center justify-center bg-purple-900/90 backdrop-blur-xs text-white p-6 transition-all">
          <div className="flex h-20 w-20 items-center justify-center rounded-2xl bg-white/10 border-2 border-dashed border-white/40 mb-4 animate-bounce">
            <Upload className="h-10 w-10 text-white" />
          </div>
          <h3 className="text-lg font-bold">Ingest Samples into Safe Static Sandbox</h3>
          <p className="mt-1 text-xs text-purple-200 text-center max-w-md">
            Release mouse to import files. Zero-execution guard will instantly hash (SHA-256/SHA-1/MD5), extract byte entropy, and evaluate static risk indicators.
          </p>
          <div className="mt-4 flex items-center gap-2 rounded-full bg-black/30 px-3 py-1 text-xs font-mono">
            <Lock className="h-3.5 w-3.5 text-purple-300" />
            <span>Target: {currentFolderTitle}</span>
          </div>
        </div>
      )}

      {/* Sub-header: Folder Title & Filter Pills */}
      <div className="flex flex-wrap items-center justify-between border-b border-slate-200 bg-white px-4 py-2.5 gap-2 shrink-0">
        <div className="flex items-center gap-2">
          <FolderOpen className="h-4 w-4 text-purple-700" />
          <h2 className="text-xs font-bold uppercase tracking-wider text-slate-800">
            {currentFolderTitle}
          </h2>
          <span className="font-mono text-[11px] text-slate-400">
            ({filteredFiles.length} {filteredFiles.length === 1 ? 'item' : 'items'})
          </span>
        </div>

        {/* Filter categories */}
        <div className="flex flex-wrap items-center gap-1">
          {categories.map(cat => (
            <button
              key={cat.id}
              onClick={() => onCategoryFilterChange(cat.id)}
              className={`rounded-md px-2 py-1 text-[11px] font-medium transition-colors ${
                categoryFilter === cat.id
                  ? 'bg-purple-900 text-white shadow-xs'
                  : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* Batch Action Bar (shows when items are selected) */}
      {selectedFileIds.size > 0 && (
        <div className="flex items-center justify-between border-b border-purple-200 bg-purple-50 px-4 py-2 text-xs font-medium text-purple-950 shrink-0 animate-in fade-in duration-100">
          <div className="flex items-center gap-3">
            <button
              onClick={allSelected ? onClearSelection : onSelectAll}
              className="flex items-center gap-1.5 text-purple-900 hover:text-purple-950 font-semibold"
            >
              {allSelected ? (
                <CheckSquare className="h-4 w-4 text-purple-800" />
              ) : (
                <Square className="h-4 w-4 text-purple-800" />
              )}
              <span>{selectedFileIds.size} selected</span>
            </button>

            <span className="text-purple-300">|</span>

            <span className="font-mono text-[11px] text-purple-800">
              Total:{' '}
              {formatBytes(
                files
                  .filter(f => selectedFileIds.has(f.id))
                  .reduce((sum, f) => sum + f.size, 0)
              )}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleBatchCopyHashes}
              className="flex items-center gap-1 rounded border border-purple-200 bg-white px-2.5 py-1 text-xs font-semibold text-purple-900 hover:bg-purple-100/60 transition-colors shadow-xs"
              title="Copy SHA-256 hash manifest for all selected files"
            >
              {copiedBatch ? (
                <>
                  <Check className="h-3.5 w-3.5 text-emerald-600" />
                  <span>Hashes Copied</span>
                </>
              ) : (
                <>
                  <Copy className="h-3.5 w-3.5" />
                  <span>Copy Hashes</span>
                </>
              )}
            </button>

            <button
              onClick={onBatchQuarantine}
              className="flex items-center gap-1 rounded border border-amber-300 bg-amber-50 px-2.5 py-1 text-xs font-semibold text-amber-900 hover:bg-amber-100 transition-colors shadow-xs"
            >
              <Lock className="h-3.5 w-3.5 text-amber-700" />
              <span>Toggle Quarantine</span>
            </button>

            <button
              onClick={onBatchDelete}
              className="flex items-center gap-1 rounded border border-rose-200 bg-rose-50 px-2.5 py-1 text-xs font-semibold text-rose-800 hover:bg-rose-100 transition-colors shadow-xs"
            >
              <Trash2 className="h-3.5 w-3.5 text-rose-600" />
              <span>Trash</span>
            </button>
          </div>
        </div>
      )}

      {/* Main Content Area: Grid or Table */}
      <div className="flex-1 overflow-y-auto p-4">
        {filteredFiles.length === 0 ? (
          /* Empty State */
          <div className="flex flex-col items-center justify-center py-20 text-center">
            <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-purple-50 text-purple-700 border border-purple-100 mb-4">
              <Upload className="h-8 w-8" />
            </div>
            <h3 className="text-sm font-semibold text-slate-800">
              No files found in this view
            </h3>
            <p className="mt-1 text-xs text-slate-500 max-w-sm">
              Drag and drop any binary, document, archive, or script directly here to begin static inspection.
            </p>
            <button
              onClick={onImportClick}
              className="mt-4 flex items-center gap-1.5 rounded-lg bg-purple-900 px-4 py-2 text-xs font-semibold text-white hover:bg-purple-800 transition-colors shadow-xs"
            >
              <Upload className="h-3.5 w-3.5" />
              <span>Import Files from Disk</span>
            </button>
          </div>
        ) : viewMode === 'grid' ? (
          /* Grid View */
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-3.5">
            {filteredFiles.map(file => (
              <FileCard
                key={file.id}
                file={file}
                isSelected={selectedFileIds.has(file.id)}
                onSelect={e => onToggleSelect(e, file)}
                onDoubleClick={f => onInspectFile(f)}
                onContextMenu={e => onContextMenu(e, file)}
              />
            ))}
          </div>
        ) : (
          /* Table / List View */
          <div className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-xs">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50/70 text-[11px] font-bold uppercase tracking-wider text-slate-500 font-mono">
                  <th className="py-2.5 pl-4 pr-2">File Name</th>
                  <th className="py-2.5 px-3">Type</th>
                  <th className="py-2.5 px-3">Size</th>
                  <th className="py-2.5 px-3">Entropy (H)</th>
                  <th className="py-2.5 px-3">Threat Profile</th>
                  <th className="py-2.5 px-3">SHA-256 Digest</th>
                  <th className="py-2.5 pl-3 pr-4 text-right">Modified</th>
                </tr>
              </thead>
              <tbody>
                {filteredFiles.map(file => (
                  <FileRow
                    key={file.id}
                    file={file}
                    isSelected={selectedFileIds.has(file.id)}
                    onSelect={e => onToggleSelect(e, file)}
                    onDoubleClick={f => onInspectFile(f)}
                    onContextMenu={e => onContextMenu(e, file)}
                  />
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
