import React from 'react';
import {
  FileText,
  FileCode,
  Binary,
  Archive,
  Image,
  ShieldAlert,
  ShieldCheck,
  AlertTriangle,
  Lock,
  Star,
  Activity,
} from 'lucide-react';
import { CyberFile } from '../types';
import { formatBytes, truncateHash } from '../utils/fileAnalyzer';

interface FileCardProps {
  file: CyberFile;
  isSelected: boolean;
  onSelect: (e: React.MouseEvent, file: CyberFile) => void;
  onContextMenu: (e: React.MouseEvent, file: CyberFile) => void;
  onDoubleClick: (file: CyberFile) => void;
}

export const FileCard: React.FC<FileCardProps> = ({
  file,
  isSelected,
  onSelect,
  onContextMenu,
  onDoubleClick,
}) => {
  const getFileIcon = () => {
    const ext = file.extension.toLowerCase();
    if (['exe', 'dll', 'sys', 'bin', 'elf', 'scr'].includes(ext)) {
      return <Binary className="h-6 w-6 text-purple-700" />;
    }
    if (['ps1', 'sh', 'bat', 'vbs', 'js', 'py'].includes(ext)) {
      return <FileCode className="h-6 w-6 text-indigo-600" />;
    }
    if (['zip', 'rar', '7z', 'tar', 'gz', 'apk'].includes(ext)) {
      return <Archive className="h-6 w-6 text-amber-600" />;
    }
    if (['png', 'jpg', 'jpeg', 'gif', 'svg'].includes(ext)) {
      return <Image className="h-6 w-6 text-cyan-600" />;
    }
    return <FileText className="h-6 w-6 text-slate-600" />;
  };

  const getRiskIndicator = () => {
    if (file.riskLevel === 'critical') {
      return (
        <span className="inline-flex items-center gap-1 rounded bg-rose-100 px-1.5 py-0.5 text-[10px] font-bold text-rose-800 border border-rose-200">
          <ShieldAlert className="h-2.5 w-2.5" /> CRITICAL
        </span>
      );
    }
    if (file.riskLevel === 'high') {
      return (
        <span className="inline-flex items-center gap-1 rounded bg-amber-100 px-1.5 py-0.5 text-[10px] font-bold text-amber-800 border border-amber-200">
          <AlertTriangle className="h-2.5 w-2.5" /> HIGH RISK
        </span>
      );
    }
    if (file.riskLevel === 'medium') {
      return (
        <span className="inline-flex items-center gap-1 rounded bg-yellow-100 px-1.5 py-0.5 text-[10px] font-medium text-yellow-800 border border-yellow-200">
          MEDIUM
        </span>
      );
    }
    if (file.riskLevel === 'low') {
      return (
        <span className="inline-flex items-center gap-1 rounded bg-blue-50 px-1.5 py-0.5 text-[10px] font-medium text-blue-700 border border-blue-200">
          LOW
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1 rounded bg-emerald-50 px-1.5 py-0.5 text-[10px] font-medium text-emerald-700 border border-emerald-200">
        <ShieldCheck className="h-2.5 w-2.5" /> BENIGN
      </span>
    );
  };

  return (
    <div
      id={`file-card-${file.id}`}
      onClick={e => onSelect(e, file)}
      onDoubleClick={() => onDoubleClick(file)}
      onContextMenu={e => onContextMenu(e, file)}
      className={`group relative flex flex-col justify-between rounded-xl border p-3.5 transition-all cursor-pointer select-none bg-white ${
        isSelected
          ? 'border-purple-600 bg-purple-50/50 shadow-sm ring-2 ring-purple-500/20'
          : 'border-slate-200 hover:border-purple-300 hover:shadow-xs'
      }`}
    >
      {/* Top row: icon, extension, risk badge */}
      <div className="flex items-start justify-between">
        <div className="relative flex h-10 w-10 items-center justify-center rounded-lg bg-slate-50 border border-slate-200/80 group-hover:border-purple-200 group-hover:bg-purple-50/60 transition-colors">
          {getFileIcon()}
          {file.permissions.quarantine && (
            <div className="absolute -bottom-1 -right-1 rounded-full bg-slate-900 p-0.5 text-white shadow-xs">
              <Lock className="h-2.5 w-2.5" />
            </div>
          )}
        </div>

        <div className="flex items-center gap-1.5">
          {file.isFavorite && <Star className="h-3.5 w-3.5 text-amber-500 fill-amber-400" />}
          {getRiskIndicator()}
        </div>
      </div>

      {/* Middle: File Name and Type */}
      <div className="mt-3">
        <h3
          className="text-xs font-semibold text-slate-900 truncate"
          title={file.name}
        >
          {file.name}
        </h3>
        <p className="mt-0.5 text-[11px] text-slate-500 truncate">{file.detectedType}</p>
      </div>

      {/* Bottom info bar */}
      <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500 font-mono">
        <span>{formatBytes(file.size)}</span>

        <div
          className={`flex items-center gap-0.5 text-[10px] px-1.5 py-0.5 rounded font-medium ${
            file.entropy >= 7.2
              ? 'bg-rose-50 text-rose-700 font-semibold'
              : 'bg-slate-100 text-slate-700'
          }`}
          title={`Shannon Entropy: ${file.entropy.toFixed(3)} bits`}
        >
          <Activity className="h-2.5 w-2.5" />
          <span>H:{file.entropy.toFixed(1)}</span>
        </div>
      </div>
    </div>
  );
};
