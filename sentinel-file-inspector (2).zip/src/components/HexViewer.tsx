import React, { useState, useMemo } from 'react';
import { Search, Copy, Check } from 'lucide-react';

interface HexViewerProps {
  bytes: number[];
  filename: string;
}

export const HexViewer: React.FC<HexViewerProps> = ({ bytes, filename }) => {
  const [hoveredOffset, setHoveredOffset] = useState<number | null>(null);
  const [searchHex, setSearchHex] = useState('');
  const [copied, setCopied] = useState(false);
  const [pageSize, setPageSize] = useState(256);
  const [currentPage, setCurrentPage] = useState(0);

  const totalBytes = bytes.length;
  const totalPages = Math.ceil(totalBytes / pageSize) || 1;

  const currentSlice = useMemo(() => {
    const start = currentPage * pageSize;
    return bytes.slice(start, start + pageSize);
  }, [bytes, currentPage, pageSize]);

  // Group slice into rows of 16 bytes
  const rows = useMemo(() => {
    const result: Array<{
      offset: number;
      bytes: number[];
      ascii: string[];
    }> = [];

    const baseOffset = currentPage * pageSize;
    for (let i = 0; i < currentSlice.length; i += 16) {
      const rowBytes = currentSlice.slice(i, i + 16);
      const rowAscii = rowBytes.map(b => (b >= 32 && b <= 126 ? String.fromCharCode(b) : '.'));
      result.push({
        offset: baseOffset + i,
        bytes: rowBytes,
        ascii: rowAscii,
      });
    }
    return result;
  }, [currentSlice, currentPage, pageSize]);

  const handleCopyHex = () => {
    const hexString = bytes
      .map(b => b.toString(16).padStart(2, '0').toUpperCase())
      .join(' ');
    navigator.clipboard.writeText(hexString);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div id="hex-viewer-container" className="flex flex-col h-full rounded-lg border border-slate-200 bg-white shadow-xs">
      {/* Hex toolbar */}
      <div className="flex flex-wrap items-center justify-between border-b border-slate-200 bg-slate-50/70 px-3 py-2 text-xs">
        <div className="flex items-center gap-2">
          <span className="font-semibold text-slate-700">Hex Inspector</span>
          <span className="rounded bg-purple-100 px-1.5 py-0.5 font-mono text-[11px] font-medium text-purple-800">
            {totalBytes} Bytes Ingested
          </span>
        </div>

        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-slate-400" />
            <input
              type="text"
              placeholder="Find byte (e.g. 4D or MZ)"
              value={searchHex}
              onChange={e => setSearchHex(e.target.value.trim())}
              className="h-7 w-36 rounded border border-slate-300 bg-white pl-7 pr-2 text-[11px] font-mono focus:border-purple-600 focus:outline-none"
            />
          </div>

          <button
            onClick={handleCopyHex}
            className="flex items-center gap-1 rounded border border-slate-300 bg-white px-2 py-1 text-[11px] font-medium text-slate-700 hover:bg-slate-100 transition-colors"
            title="Copy entire raw hex sequence to clipboard"
          >
            {copied ? (
              <>
                <Check className="h-3 w-3 text-emerald-600" />
                <span>Copied</span>
              </>
            ) : (
              <>
                <Copy className="h-3 w-3 text-slate-500" />
                <span>Copy Hex</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Hex column headers */}
      <div className="grid grid-cols-12 border-b border-slate-200 bg-slate-100/70 px-3 py-1 text-[11px] font-mono text-slate-500 font-semibold">
        <div className="col-span-2">Offset</div>
        <div className="col-span-7 tracking-wider">
          00 01 02 03 04 05 06 07  08 09 0A 0B 0C 0D 0E 0F
        </div>
        <div className="col-span-3 text-right pr-2">Decoded Text</div>
      </div>

      {/* Hex content dump */}
      <div className="flex-1 overflow-auto p-3 font-mono text-xs leading-relaxed select-text bg-[#FAF9FD]">
        {rows.length === 0 ? (
          <div className="py-8 text-center text-slate-400">No binary data to display</div>
        ) : (
          rows.map(row => (
            <div
              key={row.offset}
              className="grid grid-cols-12 py-0.5 hover:bg-purple-50/60 rounded px-1 transition-colors"
            >
              {/* Offset */}
              <div className="col-span-2 text-slate-400 select-none">
                {row.offset.toString(16).padStart(8, '0').toUpperCase()}
              </div>

              {/* 16 Hex bytes */}
              <div className="col-span-7 flex flex-wrap gap-x-1.5 text-slate-800">
                {row.bytes.map((byte, idx) => {
                  const currentGlobalOffset = row.offset + idx;
                  const isHovered = hoveredOffset === currentGlobalOffset;
                  const hexStr = byte.toString(16).padStart(2, '0').toUpperCase();
                  const isMatch =
                    searchHex &&
                    (hexStr.includes(searchHex.toUpperCase()) ||
                      String.fromCharCode(byte).toUpperCase().includes(searchHex.toUpperCase()));

                  return (
                    <span
                      key={idx}
                      onMouseEnter={() => setHoveredOffset(currentGlobalOffset)}
                      onMouseLeave={() => setHoveredOffset(null)}
                      className={`cursor-pointer rounded px-0.5 transition-all ${
                        isHovered
                          ? 'bg-purple-600 text-white font-bold ring-2 ring-purple-300'
                          : isMatch
                          ? 'bg-amber-200 text-slate-900 font-bold'
                          : byte === 0
                          ? 'text-slate-300'
                          : byte >= 32 && byte <= 126
                          ? 'text-purple-950 font-medium'
                          : 'text-slate-600'
                      }`}
                    >
                      {hexStr}
                    </span>
                  );
                })}
              </div>

              {/* ASCII representation */}
              <div className="col-span-3 flex justify-end gap-[2px] text-right font-mono pr-2">
                {row.ascii.map((char, idx) => {
                  const currentGlobalOffset = row.offset + idx;
                  const isHovered = hoveredOffset === currentGlobalOffset;

                  return (
                    <span
                      key={idx}
                      onMouseEnter={() => setHoveredOffset(currentGlobalOffset)}
                      onMouseLeave={() => setHoveredOffset(null)}
                      className={`inline-block w-3.5 text-center transition-all ${
                        isHovered
                          ? 'bg-purple-600 text-white font-bold rounded'
                          : char === '.'
                          ? 'text-slate-300'
                          : 'text-purple-900 font-medium'
                      }`}
                    >
                      {char}
                    </span>
                  );
                })}
              </div>
            </div>
          ))
        )}
      </div>

      {/* Pagination Footer */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between border-t border-slate-200 bg-slate-50 px-3 py-1.5 text-xs text-slate-600">
          <div className="flex items-center gap-2">
            <span>
              Offset range: {currentPage * pageSize} - {Math.min(totalBytes, (currentPage + 1) * pageSize)} of{' '}
              {totalBytes}
            </span>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              disabled={currentPage === 0}
              onClick={() => setCurrentPage(p => Math.max(0, p - 1))}
              className="rounded border border-slate-300 bg-white px-2 py-0.5 text-xs font-medium hover:bg-slate-100 disabled:opacity-40"
            >
              Previous
            </button>
            <span className="font-mono text-xs">
              {currentPage + 1} / {totalPages}
            </span>
            <button
              disabled={currentPage >= totalPages - 1}
              onClick={() => setCurrentPage(p => Math.min(totalPages - 1, p + 1))}
              className="rounded border border-slate-300 bg-white px-2 py-0.5 text-xs font-medium hover:bg-slate-100 disabled:opacity-40"
            >
              Next
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
