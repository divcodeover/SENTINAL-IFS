import React, { useEffect, useRef } from 'react';
import {
  Shield,
  Binary,
  FileCode,
  SlidersHorizontal,
  Copy,
  Star,
  Lock,
  Edit2,
  Trash2,
  RotateCcw,
} from 'lucide-react';
import { CyberFile } from '../types';

interface ContextMenuProps {
  x: number;
  y: number;
  file: CyberFile;
  onClose: () => void;
  onInspect: (file: CyberFile) => void;
  onOpenDiff: (file: CyberFile) => void;
  onToggleQuarantine: (fileId: string) => void;
  onToggleFavorite: (fileId: string) => void;
  onRename: (file: CyberFile) => void;
  onDelete: (fileId: string) => void;
  onRestore?: (fileId: string) => void;
}

export const ContextMenu: React.FC<ContextMenuProps> = ({
  x,
  y,
  file,
  onClose,
  onInspect,
  onOpenDiff,
  onToggleQuarantine,
  onToggleFavorite,
  onRename,
  onDelete,
  onRestore,
}) => {
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        onClose();
      }
    };
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };

    window.addEventListener('mousedown', handleClickOutside);
    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('mousedown', handleClickOutside);
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [onClose]);

  // Adjust coordinates so menu stays inside viewport
  const adjustedX = Math.min(x, window.innerWidth - 220);
  const adjustedY = Math.min(y, window.innerHeight - 320);

  return (
    <div
      ref={menuRef}
      id="file-context-menu"
      style={{ top: `${adjustedY}px`, left: `${adjustedX}px` }}
      className="fixed z-50 w-52 rounded-lg border border-slate-200 bg-white py-1 shadow-lg text-xs font-medium text-slate-700 animate-in fade-in zoom-in-95 duration-100"
    >
      {/* File name header */}
      <div className="border-b border-slate-100 px-3 py-1.5 text-[11px] font-semibold text-slate-400 truncate">
        {file.name}
      </div>

      <button
        onClick={() => {
          onInspect(file);
          onClose();
        }}
        className="flex w-full items-center gap-2 px-3 py-1.5 hover:bg-purple-50 hover:text-purple-900 transition-colors"
      >
        <Shield className="h-3.5 w-3.5 text-purple-700" />
        <span>Inspect Security Profile</span>
      </button>

      <button
        onClick={() => {
          onOpenDiff(file);
          onClose();
        }}
        className="flex w-full items-center gap-2 px-3 py-1.5 hover:bg-purple-50 hover:text-purple-900 transition-colors"
      >
        <SlidersHorizontal className="h-3.5 w-3.5 text-indigo-600" />
        <span>Compare with File...</span>
      </button>

      <button
        onClick={() => {
          navigator.clipboard.writeText(file.sha256);
          onClose();
        }}
        className="flex w-full items-center gap-2 px-3 py-1.5 hover:bg-purple-50 hover:text-purple-900 transition-colors"
      >
        <Copy className="h-3.5 w-3.5 text-slate-500" />
        <span>Copy SHA-256 Hash</span>
      </button>

      <div className="my-1 border-t border-slate-100" />

      <button
        onClick={() => {
          onToggleQuarantine(file.id);
          onClose();
        }}
        className="flex w-full items-center gap-2 px-3 py-1.5 hover:bg-purple-50 hover:text-purple-900 transition-colors"
      >
        <Lock className="h-3.5 w-3.5 text-amber-600" />
        <span>{file.permissions.quarantine ? 'Release from Quarantine' : 'Quarantine / Isolate'}</span>
      </button>

      <button
        onClick={() => {
          onToggleFavorite(file.id);
          onClose();
        }}
        className="flex w-full items-center gap-2 px-3 py-1.5 hover:bg-purple-50 hover:text-purple-900 transition-colors"
      >
        <Star className="h-3.5 w-3.5 text-amber-500" />
        <span>{file.isFavorite ? 'Remove Favorite' : 'Add to Favorites'}</span>
      </button>

      <button
        onClick={() => {
          onRename(file);
          onClose();
        }}
        className="flex w-full items-center gap-2 px-3 py-1.5 hover:bg-purple-50 hover:text-purple-900 transition-colors"
      >
        <Edit2 className="h-3.5 w-3.5 text-slate-500" />
        <span>Rename</span>
      </button>

      <div className="my-1 border-t border-slate-100" />

      {file.isTrash && onRestore ? (
        <button
          onClick={() => {
            onRestore(file.id);
            onClose();
          }}
          className="flex w-full items-center gap-2 px-3 py-1.5 text-emerald-700 hover:bg-emerald-50 transition-colors"
        >
          <RotateCcw className="h-3.5 w-3.5" />
          <span>Restore File</span>
        </button>
      ) : (
        <button
          onClick={() => {
            onDelete(file.id);
            onClose();
          }}
          className="flex w-full items-center gap-2 px-3 py-1.5 text-rose-600 hover:bg-rose-50 transition-colors"
        >
          <Trash2 className="h-3.5 w-3.5" />
          <span>Move to Quarantine / Trash</span>
        </button>
      )}
    </div>
  );
};
