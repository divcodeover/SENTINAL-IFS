import React, { useState } from 'react';
import { HelpCircle } from 'lucide-react';

interface EntropyGaugeProps {
  entropy: number;
  distribution?: number[];
  interpretation: string;
}

export const EntropyGauge: React.FC<EntropyGaugeProps> = ({
  entropy,
  distribution = [],
  interpretation,
}) => {
  const [hoveredBucket, setHoveredBucket] = useState<{ index: number; val: number } | null>(null);

  // Entropy is between 0 and 8 bits per byte
  const percentage = Math.min(100, (entropy / 8.0) * 100);

  const getColor = (val: number) => {
    if (val >= 7.2) return { text: 'text-rose-600', bar: 'bg-rose-500', border: 'border-rose-200', bg: 'bg-rose-50' };
    if (val >= 5.0) return { text: 'text-purple-700', bar: 'bg-purple-600', border: 'border-purple-200', bg: 'bg-purple-50' };
    return { text: 'text-emerald-700', bar: 'bg-emerald-600', border: 'border-emerald-200', bg: 'bg-emerald-50' };
  };

  const scheme = getColor(entropy);

  // Group 256 buckets into 64 display bars for clean rendering
  const bins: number[] = [];
  const binSize = 4;
  for (let i = 0; i < 256; i += binSize) {
    let sum = 0;
    for (let j = 0; j < binSize; j++) {
      sum += distribution[i + j] || 0;
    }
    bins.push(Math.min(100, Math.round(sum / binSize)));
  }

  return (
    <div id="entropy-analysis-gauge" className="space-y-4">
      {/* Metric header */}
      <div className="flex items-start justify-between">
        <div>
          <div className="flex items-center gap-1.5">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
              Shannon Entropy (H)
            </span>
            <div className="group relative cursor-help">
              <HelpCircle className="h-3.5 w-3.5 text-slate-400" />
              <div className="pointer-events-none absolute left-0 bottom-full mb-1 hidden w-56 rounded-md bg-slate-900 p-2 text-xs text-slate-200 shadow-lg group-hover:block z-50">
                Measures byte randomness on a 0.00 to 8.00 bit scale. Values &gt; 7.2 typically indicate encrypted shellcode, ransomware, or packed payloads.
              </div>
            </div>
          </div>
          <div className="mt-1 flex items-baseline gap-2">
            <span className={`text-2xl font-bold font-mono ${scheme.text}`}>
              {entropy.toFixed(3)}
            </span>
            <span className="text-xs font-medium text-slate-400">/ 8.000 bits</span>
          </div>
        </div>

        <span
          className={`inline-flex items-center rounded px-2 py-0.5 text-xs font-medium border ${scheme.bg} ${scheme.border} ${scheme.text}`}
        >
          {interpretation}
        </span>
      </div>

      {/* Primary meter bar */}
      <div className="space-y-1">
        <div className="h-2 w-full overflow-hidden rounded-full bg-slate-100 border border-slate-200">
          <div
            className={`h-full transition-all duration-300 ${scheme.bar}`}
            style={{ width: `${percentage}%` }}
          />
        </div>
        <div className="flex justify-between text-[10px] text-slate-400 font-mono">
          <span>0.0 (Plain)</span>
          <span>4.0</span>
          <span>6.0</span>
          <span className="text-rose-600 font-medium">7.2 (Packed)</span>
          <span>8.0 (Encrypted)</span>
        </div>
      </div>

      {/* 256-Byte Distribution Spectrum */}
      <div className="rounded-lg border border-slate-200 bg-slate-50/70 p-3">
        <div className="mb-2 flex items-center justify-between text-xs text-slate-600">
          <span className="font-medium">Byte Frequency Distribution (0x00 - 0xFF)</span>
          <span className="font-mono text-[11px] text-slate-500">
            {hoveredBucket
              ? `0x${hoveredBucket.index.toString(16).padStart(2, '0').toUpperCase()} ~ ${hoveredBucket.val}%`
              : 'Hover to inspect'}
          </span>
        </div>

        {/* Histogram bars */}
        <div className="flex h-16 w-full items-end gap-[1px] bg-white p-1 rounded border border-slate-200">
          {bins.map((val, idx) => {
            const byteRangeStart = idx * binSize;
            return (
              <div
                key={idx}
                onMouseEnter={() => setHoveredBucket({ index: byteRangeStart, val })}
                onMouseLeave={() => setHoveredBucket(null)}
                className="group relative flex-1 transition-all"
                style={{ height: '100%' }}
              >
                <div
                  className={`w-full rounded-t-[1px] transition-all ${
                    val > 60 ? 'bg-purple-600' : val > 20 ? 'bg-purple-400' : 'bg-purple-200'
                  } hover:bg-violet-700`}
                  style={{ height: `${Math.max(4, val)}%` }}
                />
              </div>
            );
          })}
        </div>

        <div className="mt-1.5 flex justify-between text-[10px] text-slate-400 font-mono">
          <span>0x00 (Null)</span>
          <span>0x20 (ASCII)</span>
          <span>0x7F</span>
          <span>0xFF</span>
        </div>
      </div>
    </div>
  );
};
