import React, { useState } from 'react';
import { X, FileCheck2, Download, Printer, Shield, Check, Lock } from 'lucide-react';
import { CyberFile } from '../types';
import { formatBytes } from '../utils/fileAnalyzer';

interface SecurityReportModalProps {
  files: CyberFile[];
  onClose: () => void;
}

export const SecurityReportModal: React.FC<SecurityReportModalProps> = ({
  files,
  onClose,
}) => {
  const [copiedNotification, setCopiedNotification] = useState(false);

  const activeFiles = files.filter(f => !f.isTrash);
  const criticalCount = activeFiles.filter(f => f.riskLevel === 'critical').length;
  const highCount = activeFiles.filter(f => f.riskLevel === 'high').length;
  const mediumCount = activeFiles.filter(f => f.riskLevel === 'medium').length;
  const cleanCount = activeFiles.filter(f => f.riskLevel === 'clean' || f.riskLevel === 'low').length;
  const quarantinedCount = files.filter(f => f.permissions.quarantine || f.isTrash).length;
  const totalBytes = activeFiles.reduce((acc, f) => acc + f.size, 0);

  const reportDate = new Date().toUTCString();

  // Download JSON Report
  const handleDownloadJSON = () => {
    const reportData = {
      generatedAt: new Date().toISOString(),
      tool: 'SentinelFS Cyber Security Workstation',
      version: '2.6.0',
      sandboxGuarantees: 'Zero-execution enforced. Static entropy & cryptographic digests verified.',
      statistics: {
        totalFiles: activeFiles.length,
        totalBytes,
        criticalThreats: criticalCount,
        highThreats: highCount,
        mediumThreats: mediumCount,
        benignFiles: cleanCount,
        quarantinedArtifacts: quarantinedCount,
      },
      artifacts: files.map(f => ({
        id: f.id,
        filename: f.name,
        path: f.path,
        sizeBytes: f.size,
        mimeType: f.mimeType,
        sha256: f.sha256,
        sha1: f.sha1,
        md5: f.md5,
        shannonEntropy: f.entropy,
        detectedType: f.detectedType,
        riskLevel: f.riskLevel,
        riskScore: f.riskScore,
        isQuarantined: f.permissions.quarantine,
        riskIndicators: f.riskIndicators,
        suspiciousStringsCount: f.extractedStrings.filter(s => s.isSuspicious).length,
      })),
    };

    const blob = new Blob([JSON.stringify(reportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `sentinel_security_audit_${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Download CSV Manifest
  const handleDownloadCSV = () => {
    const headers = ['Filename', 'Size', 'Type', 'Entropy', 'RiskLevel', 'Quarantined', 'SHA256', 'MD5'];
    const rows = files.map(f => [
      `"${f.name}"`,
      f.size,
      `"${f.detectedType}"`,
      f.entropy,
      f.riskLevel,
      f.permissions.quarantine ? 'YES' : 'NO',
      f.sha256,
      f.md5,
    ]);

    const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `sentinel_file_manifest_${Date.now()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div
      id="security-report-modal"
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-xs p-4 animate-in fade-in duration-150 select-none"
    >
      <div className="flex flex-col w-full max-w-4xl max-h-[90vh] rounded-2xl border border-slate-200 bg-white shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-200 bg-[#FAF9FD] px-6 py-4">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-purple-900 text-white">
              <FileCheck2 className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                Cybersecurity Audit & Static Triage Report
              </h3>
              <p className="text-[11px] text-slate-500 font-mono">Generated: {reportDate}</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 transition-colors"
            >
              <Printer className="h-3.5 w-3.5" />
              <span>Print</span>
            </button>

            <button
              onClick={handleDownloadCSV}
              className="flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 transition-colors"
            >
              <Download className="h-3.5 w-3.5" />
              <span>CSV Manifest</span>
            </button>

            <button
              onClick={handleDownloadJSON}
              className="flex items-center gap-1.5 rounded-lg bg-purple-900 px-3 py-1.5 text-xs font-semibold text-white hover:bg-purple-800 transition-colors shadow-xs"
            >
              <Download className="h-3.5 w-3.5" />
              <span>JSON Report</span>
            </button>

            <button
              onClick={onClose}
              className="rounded p-1 text-slate-400 hover:bg-slate-200 hover:text-slate-800 transition-colors ml-2"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Printable/Scrollable Report Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 select-text">
          {/* Executive Summary Box */}
          <div className="rounded-xl border border-purple-200 bg-purple-50/50 p-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-purple-900 flex items-center gap-1.5">
                <Shield className="h-4 w-4 text-purple-700" />
                Workstation Security Assessment Overview
              </span>
              <span className="font-mono text-xs font-semibold text-purple-900">
                Status: Audit Complete
              </span>
            </div>

            <p className="text-xs text-slate-700 leading-relaxed">
              This report documents the defensive static inspection of {files.length} artifacts conducted under strict zero-execution constraints. Files were hashed with SHA-256 and MD5, checked for header anomalies, and evaluated for Shannon entropy variance to discover obfuscated or masquerading executables.
            </p>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2 text-xs">
              <div className="rounded-lg bg-white p-2.5 border border-purple-100">
                <span className="text-slate-400 block text-[11px]">Total Artifacts</span>
                <span className="text-base font-bold font-mono text-slate-900">
                  {files.length} ({formatBytes(totalBytes)})
                </span>
              </div>
              <div className="rounded-lg bg-white p-2.5 border border-rose-100">
                <span className="text-rose-500 block text-[11px]">Flagged Critical/High</span>
                <span className="text-base font-bold font-mono text-rose-600">
                  {criticalCount + highCount}
                </span>
              </div>
              <div className="rounded-lg bg-white p-2.5 border border-purple-100">
                <span className="text-purple-600 block text-[11px]">Quarantined Payloads</span>
                <span className="text-base font-bold font-mono text-purple-900">
                  {quarantinedCount}
                </span>
              </div>
              <div className="rounded-lg bg-white p-2.5 border border-emerald-100">
                <span className="text-emerald-600 block text-[11px]">Verified Benign</span>
                <span className="text-base font-bold font-mono text-emerald-700">
                  {cleanCount}
                </span>
              </div>
            </div>
          </div>

          {/* Artifact Manifest Table */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700">
              Evaluated Artifact Ledger
            </h4>
            <div className="overflow-hidden rounded-xl border border-slate-200 bg-white">
              <table className="w-full text-left text-xs border-collapse font-mono">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50 text-[10px] uppercase font-bold text-slate-500">
                    <th className="py-2 px-3">File Name</th>
                    <th className="py-2 px-2">Size</th>
                    <th className="py-2 px-2">Entropy (H)</th>
                    <th className="py-2 px-2">Risk</th>
                    <th className="py-2 px-2">SHA-256 (Truncated)</th>
                    <th className="py-2 px-3 text-right">Lock State</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {files.map(f => (
                    <tr key={f.id} className="hover:bg-slate-50">
                      <td className="py-2 px-3 font-semibold text-slate-900 font-sans max-w-xs truncate">
                        {f.name}
                      </td>
                      <td className="py-2 px-2 text-slate-600">{formatBytes(f.size)}</td>
                      <td className="py-2 px-2">
                        <span
                          className={f.entropy >= 7.2 ? 'text-rose-600 font-bold' : 'text-slate-700'}
                        >
                          {f.entropy.toFixed(2)}
                        </span>
                      </td>
                      <td className="py-2 px-2 uppercase font-bold text-[10px]">
                        <span
                          className={
                            f.riskLevel === 'critical'
                              ? 'text-rose-700'
                              : f.riskLevel === 'high'
                              ? 'text-amber-700'
                              : 'text-emerald-700'
                          }
                        >
                          {f.riskLevel}
                        </span>
                      </td>
                      <td className="py-2 px-2 text-[10px] text-slate-500">
                        {f.sha256.slice(0, 16)}...
                      </td>
                      <td className="py-2 px-3 text-right font-sans text-[10px]">
                        {f.permissions.quarantine ? (
                          <span className="font-semibold text-rose-700">QUARANTINED</span>
                        ) : (
                          <span className="text-slate-400">ACTIVE</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="border-t border-slate-200 bg-slate-50 px-6 py-3 flex items-center justify-between text-xs text-slate-500">
          <div className="flex items-center gap-1.5 font-mono">
            <Lock className="h-3.5 w-3.5 text-purple-700" />
            <span>SentinelFS Zero-Execution Static Audit Engine</span>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg bg-slate-900 px-4 py-1.5 text-xs font-semibold text-white hover:bg-slate-800 transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
