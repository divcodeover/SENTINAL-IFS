import React from 'react';
import {
  LayoutDashboard,
  FolderArchive,
  Clock,
  Star,
  Download,
  FileText,
  Monitor,
  Cpu,
  Trash2,
  FolderPlus,
  Folder as FolderIcon,
  ShieldCheck,
  Hash,
  Binary,
  SlidersHorizontal,
  FileCheck2,
  Lock,
  HardDrive,
  Presentation,
} from 'lucide-react';
import { Folder, CyberFile } from '../types';
import { formatBytes } from '../utils/fileAnalyzer';

interface SidebarProps {
  currentFolderId: string;
  onSelectFolder: (folderId: string) => void;
  systemFolders: Folder[];
  customFolders: Folder[];
  files: CyberFile[];
  onCreateFolderClick: () => void;
  onOpenDiff: () => void;
  onOpenReport: () => void;
  onOpenPresentationMode?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentFolderId,
  onSelectFolder,
  systemFolders,
  customFolders,
  files,
  onCreateFolderClick,
  onOpenDiff,
  onOpenReport,
  onOpenPresentationMode,
}) => {
  // Count files per folder
  const getFolderCount = (id: string) => {
    if (id === 'dashboard') return null;
    if (id === 'home') return files.filter(f => !f.isTrash).length;
    if (id === 'recent') return files.filter(f => !f.isTrash).slice(0, 10).length;
    if (id === 'favorites') return files.filter(f => f.isFavorite && !f.isTrash).length;
    if (id === 'trash') return files.filter(f => f.isTrash).length;
    return files.filter(f => f.folderId === id && !f.isTrash).length;
  };

  const getSystemIcon = (id: string) => {
    switch (id) {
      case 'dashboard':
        return LayoutDashboard;
      case 'home':
        return FolderArchive;
      case 'recent':
        return Clock;
      case 'favorites':
        return Star;
      case 'downloads':
        return Download;
      case 'documents':
        return FileText;
      case 'desktop':
        return Monitor;
      case 'applications':
        return Cpu;
      case 'trash':
        return Trash2;
      default:
        return FolderIcon;
    }
  };

  const totalBytes = files.reduce((acc, f) => acc + f.size, 0);
  const quarantinedCount = files.filter(f => f.permissions.quarantine || f.isTrash).length;

  return (
    <aside
      id="sentinel-sidebar"
      className="flex w-64 flex-col border-r border-slate-200 bg-[#FAF9FD] select-none shrink-0 h-full overflow-y-auto z-10"
    >
      {/* Navigation Section */}
      <div className="p-3 space-y-6">
        {/* Core System Navigation */}
        <div className="space-y-1">
          <div className="px-3 pb-1 text-[11px] font-bold uppercase tracking-wider text-slate-400">
            Workstation
          </div>
          {systemFolders.map(folder => {
            const Icon = getSystemIcon(folder.id);
            const count = getFolderCount(folder.id);
            const isActive = currentFolderId === folder.id;

            return (
              <button
                key={folder.id}
                onClick={() => onSelectFolder(folder.id)}
                className={`flex w-full items-center justify-between rounded-lg px-3 py-2 text-xs font-semibold transition-all ${
                  isActive
                    ? 'bg-purple-900 text-white shadow-xs'
                    : 'text-slate-600 hover:bg-purple-100/50 hover:text-purple-950'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Icon className={`h-4 w-4 ${isActive ? 'text-white' : 'text-purple-700'}`} />
                  <span>{folder.name}</span>
                </div>
                {count !== null && (
                  <span
                    className={`font-mono text-[10px] px-1.5 py-0.2 rounded-full ${
                      isActive
                        ? 'bg-purple-800 text-purple-200'
                        : folder.id === 'trash' && count > 0
                        ? 'bg-rose-100 text-rose-700 font-bold'
                        : 'bg-slate-200/70 text-slate-600'
                    }`}
                  >
                    {count}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Custom User Folders */}
        <div className="space-y-1">
          <div className="flex items-center justify-between px-3 pb-1 text-[11px] font-bold uppercase tracking-wider text-slate-400">
            <span>Investigative Cases</span>
            <button
              onClick={onCreateFolderClick}
              className="rounded p-0.5 text-slate-500 hover:bg-slate-200 hover:text-purple-900 transition-colors"
              title="Create new case folder"
            >
              <FolderPlus className="h-3.5 w-3.5" />
            </button>
          </div>

          {customFolders.length === 0 ? (
            <div className="px-3 py-2 text-xs text-slate-400 italic">No custom cases</div>
          ) : (
            customFolders.map(folder => {
              const count = getFolderCount(folder.id);
              const isActive = currentFolderId === folder.id;

              return (
                <button
                  key={folder.id}
                  onClick={() => onSelectFolder(folder.id)}
                  className={`flex w-full items-center justify-between rounded-lg px-3 py-2 text-xs font-medium transition-all ${
                    isActive
                      ? 'bg-purple-900 text-white shadow-xs font-semibold'
                      : 'text-slate-600 hover:bg-purple-100/50 hover:text-purple-950'
                  }`}
                >
                  <div className="flex items-center gap-2.5 truncate pr-2">
                    <FolderIcon className={`h-4 w-4 shrink-0 ${isActive ? 'text-white' : 'text-indigo-600'}`} />
                    <span className="truncate">{folder.name}</span>
                  </div>
                  {count !== null && (
                    <span
                      className={`font-mono text-[10px] px-1.5 py-0.2 rounded-full shrink-0 ${
                        isActive ? 'bg-purple-800 text-purple-200' : 'bg-slate-200/70 text-slate-600'
                      }`}
                    >
                      {count}
                    </span>
                  )}
                </button>
              );
            })
          )}
        </div>

        {/* Security Workstation Tools */}
        <div className="space-y-1">
          <div className="px-3 pb-1 text-[11px] font-bold uppercase tracking-wider text-slate-400">
            Security Tooling
          </div>

          <button
            onClick={onOpenDiff}
            className="flex w-full items-center gap-2.5 rounded-lg px-3 py-2 text-xs font-medium text-slate-600 hover:bg-purple-100/50 hover:text-purple-950 transition-colors"
          >
            <SlidersHorizontal className="h-4 w-4 text-purple-700" />
            <span>Binary Diff / Comparison</span>
          </button>

          <button
            onClick={onOpenReport}
            className="flex w-full items-center gap-2.5 rounded-lg px-3 py-2 text-xs font-medium text-slate-600 hover:bg-purple-100/50 hover:text-purple-950 transition-colors"
          >
            <FileCheck2 className="h-4 w-4 text-purple-700" />
            <span>Audit Report Generator</span>
          </button>

          {onOpenPresentationMode && (
            <button
              onClick={onOpenPresentationMode}
              className="flex w-full items-center gap-2.5 rounded-lg px-3 py-2 text-xs font-semibold text-purple-900 bg-purple-50 hover:bg-purple-100/80 transition-colors border border-purple-200/80"
            >
              <Presentation className="h-4 w-4 text-purple-700" />
              <span>Presentation Tour</span>
            </button>
          )}
        </div>
      </div>

      {/* Bottom Storage & Security Footprint Widget */}
      <div className="mt-auto p-3 border-t border-slate-200 bg-white">
        <div className="rounded-lg border border-slate-200 bg-[#FAF9FD] p-3 space-y-2 text-xs">
          <div className="flex items-center justify-between text-slate-700">
            <span className="flex items-center gap-1.5 font-semibold">
              <HardDrive className="h-3.5 w-3.5 text-purple-700" />
              <span>Sandbox Storage</span>
            </span>
            <span className="font-mono text-[11px] font-bold text-slate-900">
              {formatBytes(totalBytes)}
            </span>
          </div>

          {/* Storage progress bar */}
          <div className="h-1.5 w-full rounded-full bg-slate-200 overflow-hidden">
            <div className="h-full bg-purple-700" style={{ width: '28%' }} />
          </div>

          <div className="flex items-center justify-between text-[11px] text-slate-500">
            <span>{files.length} Ingested Samples</span>
            {quarantinedCount > 0 && (
              <span className="text-rose-600 font-bold flex items-center gap-0.5">
                <Lock className="h-2.5 w-2.5" /> {quarantinedCount} Isolated
              </span>
            )}
          </div>
        </div>
      </div>
    </aside>
  );
};
