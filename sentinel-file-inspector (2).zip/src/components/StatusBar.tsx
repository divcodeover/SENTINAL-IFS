import React from 'react';
import { ShieldCheck, HardDrive, FolderOpen, Keyboard, Lock } from 'lucide-react';
import { formatBytes } from '../utils/fileAnalyzer';

interface StatusBarProps {
  selectedCount: number;
  selectedBytes: number;
  totalFilesCount: number;
  totalBytes: number;
  currentFolderTitle: string;
  operationStatus: string;
  onOpenShortcuts: () => void;
}

export const StatusBar: React.FC<StatusBarProps> = ({
  selectedCount,
  selectedBytes,
  totalFilesCount,
  totalBytes,
  currentFolderTitle,
  operationStatus,
  onOpenShortcuts,
}) => {
  return (
    <footer
      id="sentinel-status-bar"
      className="flex h-7 w-full items-center justify-between border-t border-slate-200 bg-[#FAF9FD] px-3 text-[11px] text-slate-600 font-mono shrink-0 select-none z-30"
    >
      {/* Left: Current Folder & Selection State */}
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-1.5 text-slate-700">
          <FolderOpen className="h-3 w-3 text-purple-700" />
          <span className="font-semibold text-slate-800">{currentFolderTitle}</span>
        </div>

        <span className="text-slate-300">|</span>

        <div>
          {selectedCount > 0 ? (
            <span className="text-purple-900 font-bold">
              {selectedCount} selected ({formatBytes(selectedBytes)})
            </span>
          ) : (
            <span className="text-slate-500">{totalFilesCount} items total</span>
          )}
        </div>

        <span className="text-slate-300">|</span>

        <div className="flex items-center gap-1 text-slate-500">
          <HardDrive className="h-3 w-3" />
          <span>Storage: {formatBytes(totalBytes)}</span>
        </div>
      </div>

      {/* Right: Security Status Guarantee & Operation Status */}
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-1.5 text-purple-900 font-medium">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
          </span>
          <span className="text-[10px] uppercase tracking-wider font-bold">
            {operationStatus || 'ZERO-EXECUTION GUARD ACTIVE'}
          </span>
        </div>

        <button
          onClick={onOpenShortcuts}
          className="flex items-center gap-1 text-slate-500 hover:text-purple-900 transition-colors"
          title="View Keyboard Shortcuts"
        >
          <Keyboard className="h-3 w-3" />
          <span className="text-[10px]">Shortcuts</span>
        </button>
      </div>
    </footer>
  );
};
