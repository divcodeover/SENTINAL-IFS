import React, { useState, useEffect } from 'react';
import { X, Edit2 } from 'lucide-react';
import { CyberFile } from '../types';

interface RenameModalProps {
  file: CyberFile | null;
  onClose: () => void;
  onRename: (fileId: string, newName: string) => void;
}

export const RenameModal: React.FC<RenameModalProps> = ({
  file,
  onClose,
  onRename,
}) => {
  const [name, setName] = useState('');

  useEffect(() => {
    if (file) setName(file.name);
  }, [file]);

  if (!file) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim() && name.trim() !== file.name) {
      onRename(file.id, name.trim());
      onClose();
    }
  };

  return (
    <div
      id="rename-file-modal"
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-xs p-4 animate-in fade-in duration-100 select-none"
    >
      <div className="w-full max-w-md rounded-xl border border-slate-200 bg-white shadow-xl overflow-hidden">
        <div className="flex items-center justify-between border-b border-slate-200 bg-[#FAF9FD] px-5 py-3.5">
          <div className="flex items-center gap-2">
            <Edit2 className="h-4 w-4 text-purple-700" />
            <h3 className="text-sm font-bold text-slate-900">Rename File Artifact</h3>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-700">
            <X className="h-4 w-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          <div>
            <label className="text-xs font-semibold text-slate-700 block mb-1">
              New File Name
            </label>
            <input
              type="text"
              autoFocus
              value={name}
              onChange={e => setName(e.target.value)}
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-xs focus:border-purple-600 focus:outline-none"
            />
            <p className="mt-1 text-[11px] text-slate-500">
              Note: Changing extension will trigger re-evaluation of file signature mismatch rules.
            </p>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="rounded-lg border border-slate-200 px-3 py-1.5 text-xs font-medium text-slate-600 hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={!name.trim() || name.trim() === file.name}
              className="rounded-lg bg-purple-900 px-4 py-1.5 text-xs font-semibold text-white hover:bg-purple-800 disabled:opacity-50 shadow-xs"
            >
              Save Rename
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
