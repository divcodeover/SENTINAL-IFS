import React, { useState } from 'react';
import { X, SlidersHorizontal, Check, AlertTriangle, ArrowRightLeft, FileCode, Binary } from 'lucide-react';
import { CyberFile } from '../types';
import { formatBytes } from '../utils/fileAnalyzer';

interface FileDiffModalProps {
  files: CyberFile[];
  initialFileA?: CyberFile | null;
  onClose: () => void;
}

export const FileDiffModal: React.FC<FileDiffModalProps> = ({
  files,
  initialFileA,
  onClose,
}) => {
  const [fileAId, setFileAId] = useState<string>(
    initialFileA ? initialFileA.id : files[0]?.id || ''
  );
  const [fileBId, setFileBId] = useState<string>(
    files.find(f => f.id !== (initialFileA?.id || files[0]?.id))?.id || files[1]?.id || ''
  );

  const fileA = files.find(f => f.id === fileAId);
  const fileB = files.find(f => f.id === fileBId);

  const isHashExactMatch = fileA && fileB && fileA.sha256 === fileB.sha256;
  const isSizeMatch = fileA && fileB && fileA.size === fileB.size;
  const entropyDiff = fileA && fileB ? Math.abs(fileA.entropy - fileB.entropy) : 0;

  return (
    <div
      id="file-diff-modal"
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-xs p-4 animate-in fade-in duration-150 select-none"
    >
      <div className="flex flex-col w-full max-w-4xl max-h-[90vh] rounded-2xl border border-slate-200 bg-white shadow-2xl overflow-hidden">
        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-slate-200 bg-[#FAF9FD] px-5 py-3.5">
          <div className="flex items-center gap-2.5">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-purple-100 text-purple-800">
              <SlidersHorizontal className="h-4 w-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                Binary & Cryptographic Differential Analysis
              </h3>
              <p className="text-[11px] text-slate-500">
                Compare two artifacts for hash collisions, entropy variance, and structural divergence.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="rounded p-1 text-slate-400 hover:bg-slate-200 hover:text-slate-800 transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* File Selectors */}
        <div className="grid grid-cols-2 gap-4 border-b border-slate-200 bg-slate-50/70 p-4">
          <div>
            <label className="text-xs font-semibold text-slate-700 block mb-1">
              Primary Artifact (A)
            </label>
            <select
              value={fileAId}
              onChange={e => setFileAId(e.target.value)}
              className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-medium text-slate-800 focus:border-purple-600 focus:outline-none"
            >
              {files.map(f => (
                <option key={f.id} value={f.id}>
                  {f.name} ({formatBytes(f.size)})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-xs font-semibold text-slate-700 block mb-1">
              Secondary Artifact (B)
            </label>
            <select
              value={fileBId}
              onChange={e => setFileBId(e.target.value)}
              className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-medium text-slate-800 focus:border-purple-600 focus:outline-none"
            >
              {files.map(f => (
                <option key={f.id} value={f.id}>
                  {f.name} ({formatBytes(f.size)})
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Comparison Content */}
        <div className="flex-1 overflow-y-auto p-5 space-y-5 select-text">
          {/* Integrity Verdict Banner */}
          <div
            className={`rounded-xl border p-4 flex items-center justify-between ${
              isHashExactMatch
                ? 'border-emerald-200 bg-emerald-50 text-emerald-900'
                : 'border-purple-200 bg-purple-50/60 text-purple-950'
            }`}
          >
            <div className="flex items-center gap-3">
              {isHashExactMatch ? (
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-emerald-200 text-emerald-900">
                  <Check className="h-5 w-5" />
                </div>
              ) : (
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-purple-200 text-purple-900">
                  <ArrowRightLeft className="h-5 w-5" />
                </div>
              )}
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider">
                  {isHashExactMatch
                    ? 'Identical Cryptographic Fingerprints'
                    : 'Disparate Artifacts Detected'}
                </h4>
                <p className="text-xs mt-0.5 opacity-90">
                  {isHashExactMatch
                    ? 'Files are 100% bit-for-bit identical across SHA-256, SHA-1, and MD5 hashes.'
                    : `Artifacts have distinct cryptographic digests. Entropy delta is ${entropyDiff.toFixed(3)} bits.`}
                </p>
              </div>
            </div>

            <span className="font-mono text-xs font-bold px-2.5 py-1 rounded bg-white border border-slate-200">
              {isHashExactMatch ? 'MATCH: 100%' : 'DIFF: MISMATCH'}
            </span>
          </div>

          {/* Comparison Grid */}
          {fileA && fileB && (
            <div className="divide-y divide-slate-100 rounded-xl border border-slate-200 bg-white overflow-hidden text-xs">
              {/* Filename */}
              <div className="grid grid-cols-5 p-3 hover:bg-slate-50 transition-colors">
                <span className="col-span-1 font-semibold text-slate-500">File Name</span>
                <span className="col-span-2 font-mono text-slate-900 break-all">{fileA.name}</span>
                <span className="col-span-2 font-mono text-slate-900 break-all">{fileB.name}</span>
              </div>

              {/* Size */}
              <div className="grid grid-cols-5 p-3 hover:bg-slate-50 transition-colors">
                <span className="col-span-1 font-semibold text-slate-500">Size</span>
                <span className="col-span-2 font-mono text-slate-800">
                  {formatBytes(fileA.size)} ({fileA.size.toLocaleString()} B)
                </span>
                <span className="col-span-2 font-mono text-slate-800">
                  {formatBytes(fileB.size)} ({fileB.size.toLocaleString()} B)
                </span>
              </div>

              {/* Entropy */}
              <div className="grid grid-cols-5 p-3 hover:bg-slate-50 transition-colors">
                <span className="col-span-1 font-semibold text-slate-500">Entropy (H)</span>
                <span className="col-span-2 font-mono">
                  <span className="font-bold text-purple-900">{fileA.entropy.toFixed(3)}</span>{' '}
                  <span className="text-[11px] text-slate-500">({fileA.entropyInterpretation})</span>
                </span>
                <span className="col-span-2 font-mono">
                  <span className="font-bold text-purple-900">{fileB.entropy.toFixed(3)}</span>{' '}
                  <span className="text-[11px] text-slate-500">({fileB.entropyInterpretation})</span>
                </span>
              </div>

              {/* Detected Type */}
              <div className="grid grid-cols-5 p-3 hover:bg-slate-50 transition-colors">
                <span className="col-span-1 font-semibold text-slate-500">Type</span>
                <span className="col-span-2 text-slate-800">{fileA.detectedType}</span>
                <span className="col-span-2 text-slate-800">{fileB.detectedType}</span>
              </div>

              {/* SHA-256 */}
              <div className="grid grid-cols-5 p-3 hover:bg-slate-50 transition-colors">
                <span className="col-span-1 font-semibold text-slate-500">SHA-256</span>
                <span className="col-span-2 font-mono text-[11px] text-slate-800 break-all select-all">
                  {fileA.sha256}
                </span>
                <span className="col-span-2 font-mono text-[11px] text-slate-800 break-all select-all">
                  {fileB.sha256}
                </span>
              </div>

              {/* MD5 */}
              <div className="grid grid-cols-5 p-3 hover:bg-slate-50 transition-colors">
                <span className="col-span-1 font-semibold text-slate-500">MD5</span>
                <span className="col-span-2 font-mono text-[11px] text-slate-800 select-all">
                  {fileA.md5}
                </span>
                <span className="col-span-2 font-mono text-[11px] text-slate-800 select-all">
                  {fileB.md5}
                </span>
              </div>

              {/* Threat Level */}
              <div className="grid grid-cols-5 p-3 hover:bg-slate-50 transition-colors">
                <span className="col-span-1 font-semibold text-slate-500">Risk Profile</span>
                <span className="col-span-2 font-bold uppercase tracking-wider text-xs">
                  {fileA.riskLevel} (Score: {fileA.riskScore})
                </span>
                <span className="col-span-2 font-bold uppercase tracking-wider text-xs">
                  {fileB.riskLevel} (Score: {fileB.riskScore})
                </span>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="border-t border-slate-200 bg-slate-50 px-5 py-3 flex justify-end">
          <button
            onClick={onClose}
            className="rounded-lg bg-slate-900 px-4 py-1.5 text-xs font-semibold text-white hover:bg-slate-800 transition-colors"
          >
            Close Diff Inspector
          </button>
        </div>
      </div>
    </div>
  );
};
