import React from 'react';
import {
  Shield,
  Search,
  LayoutGrid,
  List,
  ArrowUpDown,
  FilePlus,
  FileCheck2,
  SlidersHorizontal,
  Lock,
  DownloadCloud,
  Presentation,
  Sparkles,
} from 'lucide-react';
import { SortField, SortDirection, ViewMode, CategoryFilter } from '../types';

interface TopBarProps {
  searchQuery: string;
  onSearchChange: (query: string) => void;
  viewMode: ViewMode;
  onViewModeChange: (mode: ViewMode) => void;
  sortBy: SortField;
  sortDirection: SortDirection;
  onSortChange: (field: SortField) => void;
  onToggleSortDirection: () => void;
  onImportClick: () => void;
  onOpenDiff: () => void;
  onOpenReport: () => void;
  onAddSampleData: () => void;
  onOpenPresentationMode: () => void;
}

export const TopBar: React.FC<TopBarProps> = ({
  searchQuery,
  onSearchChange,
  viewMode,
  onViewModeChange,
  sortBy,
  sortDirection,
  onSortChange,
  onToggleSortDirection,
  onImportClick,
  onOpenDiff,
  onOpenReport,
  onAddSampleData,
  onOpenPresentationMode,
}) => {
  return (
    <header
      id="sentinel-top-bar"
      className="flex h-14 w-full items-center justify-between border-b border-slate-200 bg-white px-4 shrink-0 select-none z-30 shadow-xs"
    >
      {/* Left: Brand Identity */}
      <div className="flex items-center gap-3">
        <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-purple-900 text-white shadow-xs">
          <Shield className="h-5 w-5" />
        </div>

        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-sm font-bold tracking-tight text-slate-900">
              Sentinel<span className="text-purple-700">FS</span>
            </h1>
            <span className="rounded bg-purple-100 px-1.5 py-0.2 font-mono text-[10px] font-semibold text-purple-900">
              SEC-OPS v2.6
            </span>
          </div>
          <p className="text-[10px] text-slate-400 font-medium leading-none">
            Zero-Execution Static Triage Engine
          </p>
        </div>
      </div>

      {/* Center: Search & Filter */}
      <div className="flex flex-1 max-w-md mx-6">
        <div className="relative w-full">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
          <input
            type="text"
            id="global-file-search-input"
            value={searchQuery}
            onChange={e => onSearchChange(e.target.value)}
            placeholder="Search by filename, extension, or detected type (⌘K or /)..."
            className="h-9 w-full rounded-lg border border-slate-200 bg-[#FAF9FD] pl-9 pr-8 text-xs text-slate-800 placeholder-slate-400 focus:border-purple-600 focus:bg-white focus:outline-none transition-all shadow-xs"
          />
          {searchQuery && (
            <button
              onClick={() => onSearchChange('')}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-slate-600 font-mono"
            >
              ✕
            </button>
          )}
        </div>
      </div>

      {/* Right: Actions, Sort, View Controls */}
      <div className="flex items-center gap-2">
        {/* Security Sandbox Badge */}
        <div className="hidden xl:flex items-center gap-1.5 rounded-full border border-purple-200 bg-purple-50/70 px-2.5 py-1 text-[11px] font-mono text-purple-900">
          <Lock className="h-3 w-3 text-purple-700" />
          <span>ISOLATED SANDBOX</span>
        </div>

        {/* Security Audit Report */}
        <button
          onClick={onOpenReport}
          className="flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs font-semibold text-slate-700 hover:border-purple-300 hover:bg-purple-50/40 transition-colors shadow-xs"
          title="Generate Security Audit Report"
        >
          <FileCheck2 className="h-3.5 w-3.5 text-purple-700" />
          <span className="hidden sm:inline">Audit Report</span>
        </button>

        {/* File Diff */}
        <button
          onClick={onOpenDiff}
          className="flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs font-semibold text-slate-700 hover:border-purple-300 hover:bg-purple-50/40 transition-colors shadow-xs"
          title="Compare two files side-by-side"
        >
          <SlidersHorizontal className="h-3.5 w-3.5 text-slate-600" />
          <span className="hidden sm:inline">Diff Tool</span>
        </button>

        {/* Interactive Presentation Mode Tour */}
        <button
          onClick={onOpenPresentationMode}
          className="flex items-center gap-1.5 rounded-lg border border-purple-300 bg-purple-50 px-2.5 py-1.5 text-xs font-semibold text-purple-900 hover:bg-purple-100 hover:border-purple-400 transition-colors shadow-xs"
          title="Start Student Presentation Tour Walkthrough"
        >
          <Presentation className="h-3.5 w-3.5 text-purple-700" />
          <span className="font-bold">Presentation Tour</span>
        </button>

        {/* Ingest / Upload Files */}
        <button
          onClick={onImportClick}
          className="flex items-center gap-1.5 rounded-lg bg-purple-900 px-3 py-1.5 text-xs font-semibold text-white hover:bg-purple-800 transition-colors shadow-xs"
          title="Import files for static security inspection"
        >
          <FilePlus className="h-3.5 w-3.5" />
          <span>Ingest Files</span>
        </button>

        {/* Divider */}
        <div className="h-5 w-[1px] bg-slate-200 mx-1" />

        {/* Sort selector */}
        <div className="flex items-center gap-1">
          <select
            value={sortBy}
            onChange={e => onSortChange(e.target.value as SortField)}
            className="h-8 rounded-lg border border-slate-200 bg-white px-2 text-xs font-medium text-slate-700 focus:border-purple-600 focus:outline-none"
            title="Sort files by attribute"
          >
            <option value="name">Name</option>
            <option value="size">Size</option>
            <option value="riskLevel">Risk Level</option>
            <option value="entropy">Entropy (H)</option>
            <option value="modifiedAt">Modified</option>
          </select>

          <button
            onClick={onToggleSortDirection}
            className="flex h-8 w-8 items-center justify-center rounded-lg border border-slate-200 bg-white text-slate-600 hover:bg-slate-50 transition-colors"
            title={`Sort Direction: ${sortDirection.toUpperCase()}`}
          >
            <ArrowUpDown className={`h-3.5 w-3.5 ${sortDirection === 'desc' ? 'rotate-180' : ''}`} />
          </button>
        </div>

        {/* View toggle (Grid / Table) */}
        <div className="flex items-center rounded-lg border border-slate-200 bg-slate-50 p-0.5">
          <button
            onClick={() => onViewModeChange('grid')}
            className={`flex h-7 w-7 items-center justify-center rounded-md transition-colors ${
              viewMode === 'grid'
                ? 'bg-white text-purple-900 shadow-xs font-bold'
                : 'text-slate-400 hover:text-slate-700'
            }`}
            title="Grid View"
          >
            <LayoutGrid className="h-3.5 w-3.5" />
          </button>
          <button
            onClick={() => onViewModeChange('table')}
            className={`flex h-7 w-7 items-center justify-center rounded-md transition-colors ${
              viewMode === 'table'
                ? 'bg-white text-purple-900 shadow-xs font-bold'
                : 'text-slate-400 hover:text-slate-700'
            }`}
            title="Detailed Table View"
          >
            <List className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>
    </header>
  );
};
