import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  ChevronRight,
  ChevronLeft,
  X,
  Shield,
  Upload,
  Binary,
  Cpu,
  BarChart3,
  SlidersHorizontal,
  FileCheck2,
  Lock,
  Layers,
  GraduationCap,
} from 'lucide-react';

export interface TourStep {
  title: string;
  badge: string;
  icon: React.ComponentType<{ className?: string }>;
  description: string;
  uiCallout: string;
  presenterNote: string;
  targetFolder?: string; // which folder to switch to
  targetFileId?: string; // file to highlight/inspect
  openDrawer?: boolean; // whether right inspector panel should open
}

export const PRESENTATION_STEPS: TourStep[] = [
  {
    title: 'Workstation Telemetry & Incident Overview',
    badge: 'Step 1 of 6 • Dashboard',
    icon: BarChart3,
    targetFolder: 'dashboard',
    description:
      'The primary telemetry dashboard provides instant situational awareness. It monitors total analyzed files, isolates flagged threats, displays storage consumption, and visualizes artifact type distribution.',
    uiCallout:
      'Notice the 4 high-level KPI cards (Analyzed Samples, Flagged Threats, Quarantine Isolation, Benign & Verified) and the real-time Artifact Distribution bar chart.',
    presenterNote:
      '"When an analyst or forensic responder opens SentinelFS, they are immediately greeted with live telemetry. All files are evaluated with zero OS-level execution."',
  },
  {
    title: 'Zero-Execution Ingestion & Drag-and-Drop Sandbox',
    badge: 'Step 2 of 6 • Ingestion Engine',
    icon: Upload,
    targetFolder: 'home',
    description:
      'Files can be dropped directly onto the workspace or ingested via the "Ingest Files" button. Files are parsed strictly as raw ArrayBuffers/Uint8Arrays in browser memory—bypassing host operating system execution.',
    uiCallout:
      'Look at the top right for the "Ingest Files" button, or try dragging any file from your computer directly onto the central canvas to trigger the drop zone.',
    presenterNote:
      '"Our ingestion pipeline reads raw bytes into memory without calling shell interpreters or system binaries, completely eliminating accidental malware execution."',
  },
  {
    title: 'Forensic File Explorer & Batch Operations',
    badge: 'Step 3 of 6 • File Ledger',
    icon: Layers,
    targetFolder: 'home',
    description:
      'Every file is classified with static threat badges (Critical, High, Medium, Benign), calculated Shannon entropy (H), real detected MIME types, and cryptographic fingerprints. Supports multi-selection for bulk IOC extraction.',
    uiCallout:
      'Try clicking checkboxes on multiple files: a purple Batch Action Bar will appear at the top allowing instant "Copy Hashes", "Toggle Quarantine", or "Move to Trash".',
    presenterNote:
      '"The explorer allows analysts to quickly filter by category (Executables, Scripts, Archives, High Risk) and toggle between visual Grid Cards or dense forensic Table Views."',
  },
  {
    title: 'Deep-Dive Cybersecurity Inspector: Entropy & Hashes',
    badge: 'Step 4 of 6 • Static Analysis',
    icon: Cpu,
    targetFolder: 'home',
    targetFileId: 'file_malware_1',
    openDrawer: true,
    description:
      'Clicking any artifact slides out the Cybersecurity Inspector. It calculates native SHA-256, SHA-1, and MD5 digests, plus mathematical Shannon entropy (0 to 8 bits) alongside a 256-bucket byte frequency histogram to spot packed or encrypted payloads.',
    uiCallout:
      'Check the right drawer: Notice the red "CRITICAL THREAT" indicator, the 7.82 bits entropy score (Flagged as Packed/Encrypted), and the built-in IOC Hash Matcher.',
    presenterNote:
      '"Notice how invoice_malware.exe has an entropy score of 7.82. In malware analysis, high entropy is a key signature of ransomware, cryptors, or packed executables."',
  },
  {
    title: 'Low-Level Hex Dump & Suspicious String Extraction',
    badge: 'Step 5 of 6 • Byte-Level Forensics',
    icon: Binary,
    targetFolder: 'home',
    targetFileId: 'file_malware_1',
    openDrawer: true,
    description:
      'Inspect 16-byte aligned hexadecimal memory offsets with live ASCII syncing, or review automated heuristic string extraction flagging Windows API injections, shell triggers, and persistence registry keys.',
    uiCallout:
      'Scroll down the right panel to see the interactive Hex Viewer and the Suspicious Strings Extracted table highlighting commands like "powershell.exe -enc" and "VirtualAlloc".',
    presenterNote:
      '"Instead of relying on heavy command-line utilities, an investigator gets instant hex inspections and automated regex filtering for known malware heuristics."',
  },
  {
    title: 'Binary Differential Analysis & Security Audit Reports',
    badge: 'Step 6 of 6 • Incident Documentation',
    icon: FileCheck2,
    targetFolder: 'home',
    description:
      'Compare suspect files side-by-side using the Binary Diff Tool, or generate exportable Security Audit Reports in JSON, CSV manifest, and printable formats for incident ticket submission.',
    uiCallout:
      'See the "Audit Report" and "Diff Tool" buttons on the top bar. They allow one-click export of IOC manifests directly to enterprise SIEM platforms.',
    presenterNote:
      '"When an investigation concludes, documentation is paramount. SentinelFS generates verifiable cryptographic audit ledgers ready for executive briefing or peer review."',
  },
];

interface PresentationModeProps {
  isOpen: boolean;
  onClose: () => void;
  onApplyStepState: (step: TourStep) => void;
  onOpenDiff: () => void;
  onOpenReport: () => void;
}

export const PresentationMode: React.FC<PresentationModeProps> = ({
  isOpen,
  onClose,
  onApplyStepState,
  onOpenDiff,
  onOpenReport,
}) => {
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [isMinimized, setIsMinimized] = useState(false);

  const currentStep = PRESENTATION_STEPS[currentStepIndex];
  const StepIcon = currentStep.icon;

  // Apply state whenever step index changes
  useEffect(() => {
    if (isOpen) {
      onApplyStepState(PRESENTATION_STEPS[currentStepIndex]);
    }
  }, [currentStepIndex, isOpen, onApplyStepState]);

  if (!isOpen) return null;

  const handleNext = () => {
    if (currentStepIndex < PRESENTATION_STEPS.length - 1) {
      setCurrentStepIndex(prev => prev + 1);
    } else {
      onClose();
    }
  };

  const handlePrev = () => {
    if (currentStepIndex > 0) {
      setCurrentStepIndex(prev => prev - 1);
    }
  };

  const handleJumpToStep = (index: number) => {
    setCurrentStepIndex(index);
  };

  return (
    <>
      {/* Floating Presentation Guide Card */}
      <div
        id="sentinel-presentation-overlay"
        className={`fixed z-50 transition-all duration-200 select-none shadow-2xl ${
          isMinimized
            ? 'bottom-10 right-10 w-72'
            : 'bottom-8 left-1/2 -translate-x-1/2 w-[92vw] max-w-2xl'
        }`}
      >
        <div className="rounded-2xl border-2 border-purple-600 bg-white/95 backdrop-blur-md shadow-2xl overflow-hidden">
          {/* Guide Header */}
          <div className="flex items-center justify-between border-b border-purple-100 bg-[#FAF9FD] px-5 py-3">
            <div className="flex items-center gap-2.5">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-purple-900 text-white shadow-xs">
                <GraduationCap className="h-4 w-4" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-slate-900">
                    SentinelFS Interactive Demo Tour
                  </span>
                  <span className="rounded-full bg-purple-100 px-2 py-0.5 text-[10px] font-mono font-bold text-purple-900">
                    STUDENT CAPSTONE DEMO
                  </span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-1.5">
              <button
                onClick={() => setIsMinimized(!isMinimized)}
                className="rounded px-2 py-1 text-[11px] font-semibold text-slate-500 hover:bg-slate-200 transition-colors"
              >
                {isMinimized ? 'Expand Guide' : 'Minimize'}
              </button>
              <button
                onClick={onClose}
                className="rounded p-1 text-slate-400 hover:bg-slate-200 hover:text-slate-800 transition-colors"
                title="Exit Presentation Mode"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
          </div>

          {!isMinimized && (
            <div className="p-5 space-y-4">
              {/* Step indicator bar */}
              <div className="flex items-center justify-between text-xs text-slate-500">
                <div className="flex items-center gap-2">
                  <span className="flex h-5 w-5 items-center justify-center rounded-full bg-purple-900 text-white font-mono text-[10px] font-bold">
                    {currentStepIndex + 1}
                  </span>
                  <span className="font-semibold text-purple-900">{currentStep.badge}</span>
                </div>
                <div className="flex items-center gap-1">
                  {PRESENTATION_STEPS.map((_, idx) => (
                    <button
                      key={idx}
                      onClick={() => handleJumpToStep(idx)}
                      className={`h-1.5 rounded-full transition-all ${
                        idx === currentStepIndex
                          ? 'w-6 bg-purple-900'
                          : 'w-2 bg-slate-200 hover:bg-purple-300'
                      }`}
                      title={`Jump to step ${idx + 1}`}
                    />
                  ))}
                </div>
              </div>

              {/* Step Title & Icon */}
              <div className="flex items-start gap-3">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-purple-100 text-purple-900 border border-purple-200">
                  <StepIcon className="h-5 w-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900 leading-snug">
                    {currentStep.title}
                  </h3>
                  <p className="mt-1 text-xs text-slate-600 leading-relaxed">
                    {currentStep.description}
                  </p>
                </div>
              </div>

              {/* Interactive Callout Highlight Box */}
              <div className="rounded-xl border border-purple-200 bg-purple-50/70 p-3 space-y-1 text-xs">
                <div className="font-bold text-purple-900 flex items-center gap-1.5">
                  <Sparkles className="h-3.5 w-3.5 text-purple-700" />
                  <span>Interactive UI Guide: Look & Click</span>
                </div>
                <p className="text-purple-950 font-medium leading-relaxed">
                  {currentStep.uiCallout}
                </p>
              </div>

              {/* Student Presenter Script / Spoken Cue */}
              <div className="rounded-xl border border-slate-200 bg-slate-50/80 p-3 text-xs">
                <span className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-0.5">
                  Suggested Presenter Speaking Note:
                </span>
                <p className="text-slate-700 italic font-mono text-[11px] leading-relaxed">
                  {currentStep.presenterNote}
                </p>
              </div>

              {/* Contextual Action Shortcut Buttons */}
              {currentStepIndex === 5 && (
                <div className="flex items-center gap-2 pt-1">
                  <button
                    onClick={onOpenDiff}
                    className="flex-1 flex items-center justify-center gap-1.5 rounded-lg border border-slate-300 bg-white py-1.5 text-xs font-semibold text-slate-800 hover:bg-slate-50 shadow-xs"
                  >
                    <SlidersHorizontal className="h-3.5 w-3.5 text-purple-700" />
                    <span>Launch Binary Diff</span>
                  </button>
                  <button
                    onClick={onOpenReport}
                    className="flex-1 flex items-center justify-center gap-1.5 rounded-lg border border-purple-300 bg-purple-100/60 py-1.5 text-xs font-semibold text-purple-900 hover:bg-purple-200/60 shadow-xs"
                  >
                    <FileCheck2 className="h-3.5 w-3.5 text-purple-700" />
                    <span>View Audit Report</span>
                  </button>
                </div>
              )}

              {/* Navigation Controls (Back / Next / Finish) */}
              <div className="flex items-center justify-between pt-2 border-t border-slate-100">
                <button
                  onClick={handlePrev}
                  disabled={currentStepIndex === 0}
                  className="flex items-center gap-1 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 disabled:opacity-40 transition-colors shadow-xs"
                >
                  <ChevronLeft className="h-4 w-4" />
                  <span>Previous</span>
                </button>

                <span className="text-[11px] font-mono text-slate-400">
                  Step {currentStepIndex + 1} of {PRESENTATION_STEPS.length}
                </span>

                <button
                  onClick={handleNext}
                  className="flex items-center gap-1.5 rounded-lg bg-purple-900 px-4 py-1.5 text-xs font-semibold text-white hover:bg-purple-800 transition-colors shadow-xs"
                >
                  <span>
                    {currentStepIndex === PRESENTATION_STEPS.length - 1 ? 'Finish Tour' : 'Next Step'}
                  </span>
                  <ChevronRight className="h-4 w-4" />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
};
