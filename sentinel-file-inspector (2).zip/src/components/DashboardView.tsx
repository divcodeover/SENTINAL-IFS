import React from 'react';
import {
  ShieldAlert,
  ShieldCheck,
  AlertTriangle,
  HardDrive,
  FileCode,
  Binary,
  Archive,
  FileText,
  Lock,
  ArrowRight,
  Upload,
  CheckCircle2,
  Clock,
  Sparkles,
} from 'lucide-react';
import { CyberFile } from '../types';
import { formatBytes, truncateHash } from '../utils/fileAnalyzer';

interface DashboardViewProps {
  files: CyberFile[];
  onSelectFile: (file: CyberFile) => void;
  onImportClick: () => void;
  onNavigateToFolder: (folderId: string) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  files,
  onSelectFile,
  onImportClick,
  onNavigateToFolder,
}) => {
  const activeFiles = files.filter(f => !f.isTrash);
  const totalFiles = activeFiles.length;
  const totalBytes = activeFiles.reduce((acc, f) => acc + f.size, 0);

  const criticalCount = activeFiles.filter(f => f.riskLevel === 'critical').length;
  const highRiskCount = activeFiles.filter(f => f.riskLevel === 'high').length;
  const mediumRiskCount = activeFiles.filter(f => f.riskLevel === 'medium').length;
  const benignCount = activeFiles.filter(f => f.riskLevel === 'clean' || f.riskLevel === 'low').length;
  const quarantinedCount = files.filter(f => f.permissions.quarantine || f.isTrash).length;

  // File type distribution
  const typeCounts = {
    executables: activeFiles.filter(f =>
      ['exe', 'dll', 'sys', 'bin', 'elf', 'scr'].includes(f.extension.toLowerCase())
    ).length,
    scripts: activeFiles.filter(f =>
      ['ps1', 'sh', 'bat', 'vbs', 'js', 'py'].includes(f.extension.toLowerCase())
    ).length,
    archives: activeFiles.filter(f =>
      ['zip', '7z', 'tar', 'gz', 'apk', 'rar'].includes(f.extension.toLowerCase())
    ).length,
    documents: activeFiles.filter(f =>
      ['pdf', 'docx', 'xlsx', 'txt', 'json', 'xml', 'md', 'sql'].includes(f.extension.toLowerCase())
    ).length,
  };

  const flaggedFiles = activeFiles.filter(
    f => f.riskLevel === 'critical' || f.riskLevel === 'high' || f.riskLevel === 'medium'
  );

  return (
    <div id="sentinel-dashboard-view" className="flex-1 overflow-y-auto p-6 space-y-6 bg-[#FAF9FD]">
      {/* Welcome Banner / Overview Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 rounded-xl border border-purple-200 bg-white p-5 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-lg font-bold text-slate-900">Cybersecurity Workstation Telemetry</h2>
            <span className="rounded-full bg-purple-100 px-2.5 py-0.5 text-xs font-semibold text-purple-900">
              Live Static Analysis
            </span>
          </div>
          <p className="mt-1 text-xs text-slate-500 max-w-2xl leading-relaxed">
            All ingested binaries and documents are quarantined in client memory. No local code is executed. Cryptographic integrity and entropy are calculated natively.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onImportClick}
            className="flex items-center gap-2 rounded-lg bg-purple-900 px-4 py-2 text-xs font-semibold text-white hover:bg-purple-800 transition-colors shadow-xs"
          >
            <Upload className="h-4 w-4" />
            <span>Ingest More Samples</span>
          </button>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Ingested */}
        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-xs font-semibold uppercase tracking-wider">Analyzed Samples</span>
            <HardDrive className="h-4 w-4 text-purple-700" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-slate-900">{totalFiles}</span>
            <span className="text-xs font-mono text-slate-500">({formatBytes(totalBytes)})</span>
          </div>
          <div className="mt-2 text-[11px] text-slate-500">
            Across {files.filter(f => f.isTrash).length} quarantined & {activeFiles.length} active items
          </div>
        </div>

        {/* Flagged Risks */}
        <div className="rounded-xl border border-rose-200 bg-white p-4 shadow-xs">
          <div className="flex items-center justify-between text-rose-800">
            <span className="text-xs font-semibold uppercase tracking-wider">Flagged Threats</span>
            <ShieldAlert className="h-4 w-4 text-rose-600" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-rose-600">
              {criticalCount + highRiskCount}
            </span>
            <span className="text-xs font-medium text-rose-700">
              ({criticalCount} critical, {highRiskCount} high)
            </span>
          </div>
          <div className="mt-2 text-[11px] text-rose-700 font-medium">
            Requires security review before usage
          </div>
        </div>

        {/* Quarantined Isolation */}
        <div className="rounded-xl border border-purple-200 bg-white p-4 shadow-xs">
          <div className="flex items-center justify-between text-purple-900">
            <span className="text-xs font-semibold uppercase tracking-wider">Quarantine Isolation</span>
            <Lock className="h-4 w-4 text-purple-700" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-purple-900">
              {quarantinedCount}
            </span>
            <span className="text-xs font-mono text-purple-700">Payloads Locked</span>
          </div>
          <div className="mt-2 text-[11px] text-purple-800">
            Zero-Execution lock enforced on binaries
          </div>
        </div>

        {/* Benign / Verified */}
        <div className="rounded-xl border border-emerald-200 bg-white p-4 shadow-xs">
          <div className="flex items-center justify-between text-emerald-800">
            <span className="text-xs font-semibold uppercase tracking-wider">Benign & Verified</span>
            <ShieldCheck className="h-4 w-4 text-emerald-600" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-emerald-700">{benignCount}</span>
            <span className="text-xs font-medium text-emerald-800">Clean Signatures</span>
          </div>
          <div className="mt-2 text-[11px] text-emerald-700">
            Normal entropy & verified headers
          </div>
        </div>
      </div>

      {/* Two Column Layout: Type Distribution & Flagged Items */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Ingestion Type Breakdown */}
        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs space-y-4">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700">
            Artifact Type Distribution
          </h3>

          <div className="space-y-3 text-xs">
            {/* Executables */}
            <div className="space-y-1">
              <div className="flex justify-between font-medium">
                <span className="flex items-center gap-1.5 text-slate-700">
                  <Binary className="h-3.5 w-3.5 text-purple-700" /> Executables & DLLs
                </span>
                <span className="font-mono text-slate-900">{typeCounts.executables}</span>
              </div>
              <div className="h-2 w-full rounded-full bg-slate-100 overflow-hidden">
                <div
                  className="h-full bg-purple-700"
                  style={{ width: `${totalFiles ? (typeCounts.executables / totalFiles) * 100 : 0}%` }}
                />
              </div>
            </div>

            {/* Scripts */}
            <div className="space-y-1">
              <div className="flex justify-between font-medium">
                <span className="flex items-center gap-1.5 text-slate-700">
                  <FileCode className="h-3.5 w-3.5 text-indigo-600" /> Scripts & Shell
                </span>
                <span className="font-mono text-slate-900">{typeCounts.scripts}</span>
              </div>
              <div className="h-2 w-full rounded-full bg-slate-100 overflow-hidden">
                <div
                  className="h-full bg-indigo-600"
                  style={{ width: `${totalFiles ? (typeCounts.scripts / totalFiles) * 100 : 0}%` }}
                />
              </div>
            </div>

            {/* Archives */}
            <div className="space-y-1">
              <div className="flex justify-between font-medium">
                <span className="flex items-center gap-1.5 text-slate-700">
                  <Archive className="h-3.5 w-3.5 text-amber-600" /> Archives & Packages
                </span>
                <span className="font-mono text-slate-900">{typeCounts.archives}</span>
              </div>
              <div className="h-2 w-full rounded-full bg-slate-100 overflow-hidden">
                <div
                  className="h-full bg-amber-500"
                  style={{ width: `${totalFiles ? (typeCounts.archives / totalFiles) * 100 : 0}%` }}
                />
              </div>
            </div>

            {/* Documents */}
            <div className="space-y-1">
              <div className="flex justify-between font-medium">
                <span className="flex items-center gap-1.5 text-slate-700">
                  <FileText className="h-3.5 w-3.5 text-slate-600" /> Documents & Config
                </span>
                <span className="font-mono text-slate-900">{typeCounts.documents}</span>
              </div>
              <div className="h-2 w-full rounded-full bg-slate-100 overflow-hidden">
                <div
                  className="h-full bg-slate-500"
                  style={{ width: `${totalFiles ? (typeCounts.documents / totalFiles) * 100 : 0}%` }}
                />
              </div>
            </div>
          </div>

          <div className="pt-2 border-t border-slate-100">
            <div className="rounded-lg bg-purple-50 p-3 text-[11px] text-purple-900 space-y-1">
              <div className="font-bold flex items-center gap-1">
                <CheckCircle2 className="h-3.5 w-3.5 text-purple-700" />
                <span>Zero-Trust Protocol Active</span>
              </div>
              <p className="text-purple-800 leading-relaxed">
                Executables, scripts, and archives are never evaluated in browser execution contexts. Only cryptographic digests and static byte frequencies are mapped.
              </p>
            </div>
          </div>
        </div>

        {/* Right 2 cols: Flagged Anomalies & Threat Triage */}
        <div className="lg:col-span-2 rounded-xl border border-slate-200 bg-white p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700">
                Security Triage & Flagged Artifacts ({flaggedFiles.length})
              </h3>
              <p className="text-xs text-slate-500">
                Files exhibiting high entropy, masquerading extensions, or suspicious command strings.
              </p>
            </div>
            <button
              onClick={() => onNavigateToFolder('home')}
              className="text-xs font-semibold text-purple-700 hover:text-purple-900 flex items-center gap-1"
            >
              <span>View All Files</span>
              <ArrowRight className="h-3.5 w-3.5" />
            </button>
          </div>

          <div className="divide-y divide-slate-100 rounded-lg border border-slate-200 overflow-hidden text-xs">
            {flaggedFiles.length === 0 ? (
              <div className="p-6 text-center text-slate-400">
                No threats or high-entropy anomalies detected in current workspace.
              </div>
            ) : (
              flaggedFiles.slice(0, 6).map(file => (
                <div
                  key={file.id}
                  onClick={() => onSelectFile(file)}
                  className="flex items-center justify-between p-3 hover:bg-purple-50/40 transition-colors cursor-pointer"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="shrink-0">
                      {file.riskLevel === 'critical' ? (
                        <ShieldAlert className="h-4 w-4 text-rose-600" />
                      ) : (
                        <AlertTriangle className="h-4 w-4 text-amber-600" />
                      )}
                    </div>
                    <div className="min-w-0">
                      <div className="font-semibold text-slate-900 truncate">
                        {file.name}
                      </div>
                      <div className="text-[11px] text-slate-500 flex items-center gap-2">
                        <span>{file.detectedType}</span>
                        <span>•</span>
                        <span className="font-mono">H:{file.entropy.toFixed(2)}</span>
                        <span>•</span>
                        <span className="font-mono">{formatBytes(file.size)}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 shrink-0">
                    <span
                      className={`rounded px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider ${
                        file.riskLevel === 'critical'
                          ? 'bg-rose-100 text-rose-800'
                          : file.riskLevel === 'high'
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-yellow-100 text-yellow-800'
                      }`}
                    >
                      {file.riskLevel}
                    </span>
                    <button
                      onClick={e => {
                        e.stopPropagation();
                        onSelectFile(file);
                      }}
                      className="rounded border border-slate-200 bg-white px-2.5 py-1 text-xs font-medium text-purple-900 hover:bg-purple-50 transition-colors"
                    >
                      Inspect
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
