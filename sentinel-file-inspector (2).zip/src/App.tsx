import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import {
  CyberFile,
  Folder,
  ViewMode,
  SortField,
  SortDirection,
  CategoryFilter,
} from './types';
import { SYSTEM_FOLDERS, INITIAL_CUSTOM_FOLDERS, INITIAL_SAMPLE_FILES } from './utils/sampleData';
import { analyzeBrowserFile } from './utils/fileAnalyzer';
import { TopBar } from './components/TopBar';
import { Sidebar } from './components/Sidebar';
import { FileBrowser } from './components/FileBrowser';
import { InspectorPanel } from './components/InspectorPanel';
import { DashboardView } from './components/DashboardView';
import { FileDiffModal } from './components/FileDiffModal';
import { SecurityReportModal } from './components/SecurityReportModal';
import { CreateFolderModal } from './components/CreateFolderModal';
import { KeyboardShortcutsModal } from './components/KeyboardShortcutsModal';
import { RenameModal } from './components/RenameModal';
import { ContextMenu } from './components/ContextMenu';
import { StatusBar } from './components/StatusBar';
import { PresentationMode, TourStep } from './components/PresentationMode';

export default function App() {
  // --- Persistent State ---
  const [files, setFiles] = useState<CyberFile[]>(() => {
    try {
      const saved = localStorage.getItem('sentinel_files');
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return INITIAL_SAMPLE_FILES;
  });

  const [customFolders, setCustomFolders] = useState<Folder[]>(() => {
    try {
      const saved = localStorage.getItem('sentinel_folders');
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return INITIAL_CUSTOM_FOLDERS;
  });

  // Save changes to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('sentinel_files', JSON.stringify(files));
    } catch {
      // ignore quota
    }
  }, [files]);

  useEffect(() => {
    try {
      localStorage.setItem('sentinel_folders', JSON.stringify(customFolders));
    } catch {
      // ignore
    }
  }, [customFolders]);

  // --- UI Navigation State ---
  const [currentFolderId, setCurrentFolderId] = useState<string>('dashboard');
  const [selectedFileIds, setSelectedFileIds] = useState<Set<string>>(new Set());
  const [inspectedFileId, setInspectedFileId] = useState<string | null>(null);

  // --- Filtering & Sorting ---
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<CategoryFilter>('all');
  const [sortBy, setSortBy] = useState<SortField>('name');
  const [sortDirection, setSortDirection] = useState<SortDirection>('asc');
  const [viewMode, setViewMode] = useState<ViewMode>('grid');

  // --- Modals State ---
  const [diffModalFile, setDiffModalFile] = useState<CyberFile | null>(null);
  const [isDiffModalOpen, setIsDiffModalOpen] = useState(false);
  const [isReportModalOpen, setIsReportModalOpen] = useState(false);
  const [isCreateFolderOpen, setIsCreateFolderOpen] = useState(false);
  const [isShortcutsOpen, setIsShortcutsOpen] = useState(false);
  const [renamingFile, setRenamingFile] = useState<CyberFile | null>(null);
  const [isPresentationOpen, setIsPresentationOpen] = useState(false);

  // --- Context Menu & Toast ---
  const [contextMenu, setContextMenu] = useState<{
    x: number;
    y: number;
    file: CyberFile;
  } | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [operationStatus, setOperationStatus] = useState<string>('SANDBOX SECURE • ZERO EXECUTION');

  // Hidden file input for manual file ingestion
  const fileInputRef = useRef<HTMLInputElement>(null);

  const showToast = useCallback((msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(curr => (curr === msg ? null : curr));
    }, 2500);
  }, []);

  // Find currently inspected file
  const inspectedFile = useMemo(() => {
    if (!inspectedFileId) return null;
    return files.find(f => f.id === inspectedFileId) || null;
  }, [files, inspectedFileId]);

  // Determine current folder title
  const currentFolderTitle = useMemo(() => {
    const sys = SYSTEM_FOLDERS.find(f => f.id === currentFolderId);
    if (sys) return sys.name;
    const cust = customFolders.find(f => f.id === currentFolderId);
    if (cust) return cust.name;
    return 'Workstation Files';
  }, [currentFolderId, customFolders]);

  // Filter files belonging to current folder
  const currentFolderFiles = useMemo(() => {
    let list: CyberFile[] = [];

    if (currentFolderId === 'home') {
      list = files.filter(f => !f.isTrash);
    } else if (currentFolderId === 'recent') {
      list = files.filter(f => !f.isTrash).slice(0, 10);
    } else if (currentFolderId === 'favorites') {
      list = files.filter(f => f.isFavorite && !f.isTrash);
    } else if (currentFolderId === 'trash') {
      list = files.filter(f => f.isTrash);
    } else if (currentFolderId === 'dashboard') {
      list = files;
    } else {
      list = files.filter(f => f.folderId === currentFolderId && !f.isTrash);
    }

    // Apply search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      list = list.filter(
        f =>
          f.name.toLowerCase().includes(q) ||
          f.extension.toLowerCase().includes(q) ||
          f.detectedType.toLowerCase().includes(q) ||
          f.sha256.toLowerCase().includes(q)
      );
    }

    // Apply Sorting
    return [...list].sort((a, b) => {
      let comparison = 0;
      if (sortBy === 'name') {
        comparison = a.name.localeCompare(b.name);
      } else if (sortBy === 'size') {
        comparison = a.size - b.size;
      } else if (sortBy === 'entropy') {
        comparison = a.entropy - b.entropy;
      } else if (sortBy === 'modifiedAt') {
        comparison = new Date(a.modifiedAt).getTime() - new Date(b.modifiedAt).getTime();
      } else if (sortBy === 'riskLevel') {
        const rank = { critical: 4, high: 3, medium: 2, low: 1, clean: 0 };
        comparison = rank[a.riskLevel] - rank[b.riskLevel];
      }
      return sortDirection === 'asc' ? comparison : -comparison;
    });
  }, [files, currentFolderId, searchQuery, sortBy, sortDirection]);

  // --- File Selection Handlers ---
  const handleToggleSelect = (e: React.MouseEvent, file: CyberFile) => {
    e.stopPropagation();

    // Auto-inspect clicked file
    setInspectedFileId(file.id);

    setSelectedFileIds(prev => {
      const next = new Set(prev);
      if (e.shiftKey || e.metaKey || e.ctrlKey) {
        if (next.has(file.id)) next.delete(file.id);
        else next.add(file.id);
      } else {
        // Single select
        next.clear();
        next.add(file.id);
      }
      return next;
    });
  };

  const handleSelectAll = () => {
    setSelectedFileIds(new Set(currentFolderFiles.map(f => f.id)));
  };

  const handleClearSelection = () => {
    setSelectedFileIds(new Set());
  };

  const handleInspectFile = (file: CyberFile) => {
    setInspectedFileId(file.id);
    setSelectedFileIds(new Set([file.id]));
  };

  const handleContextMenu = (e: React.MouseEvent, file: CyberFile) => {
    e.preventDefault();
    e.stopPropagation();
    setContextMenu({ x: e.clientX, y: e.clientY, file });
    if (!selectedFileIds.has(file.id)) {
      setSelectedFileIds(new Set([file.id]));
      setInspectedFileId(file.id);
    }
  };

  // --- Ingestion Handler (Drag & Drop or Manual File Pick) ---
  const handleFilesDropped = async (droppedFiles: FileList | File[]) => {
    setOperationStatus('INGESTING SAMPLES • HASHING & ANALYZING...');
    showToast(`Analyzing ${droppedFiles.length} file(s) into sandbox...`);

    const targetFolderId =
      currentFolderId === 'dashboard' || currentFolderId === 'trash' ? 'downloads' : currentFolderId;
    const targetPath = `/${targetFolderId}`;

    const newCyberFiles: CyberFile[] = [];

    for (let i = 0; i < droppedFiles.length; i++) {
      const file = droppedFiles[i];
      try {
        const analyzed = await analyzeBrowserFile(file, targetFolderId, targetPath);
        newCyberFiles.push(analyzed);
      } catch (err) {
        console.error('Error analyzing file:', err);
      }
    }

    if (newCyberFiles.length > 0) {
      setFiles(prev => [...newCyberFiles, ...prev]);
      setSelectedFileIds(new Set(newCyberFiles.map(f => f.id)));
      setInspectedFileId(newCyberFiles[0].id);

      const quarantinedCount = newCyberFiles.filter(f => f.permissions.quarantine).length;
      if (quarantinedCount > 0) {
        showToast(
          `Ingested ${newCyberFiles.length} file(s). ${quarantinedCount} high-risk artifact(s) isolated.`
        );
      } else {
        showToast(`Successfully ingested ${newCyberFiles.length} artifact(s).`);
      }
    }

    setOperationStatus('SANDBOX SECURE • ZERO EXECUTION');
  };

  // Manual File Selector Change
  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      handleFilesDropped(e.target.files);
    }
    e.target.value = ''; // Reset
  };

  // --- Operations on Files ---
  const handleToggleQuarantine = (fileId: string) => {
    setFiles(prev =>
      prev.map(f => {
        if (f.id === fileId) {
          const newQuarantine = !f.permissions.quarantine;
          showToast(newQuarantine ? `Locked ${f.name} in quarantine.` : `Released ${f.name} from quarantine.`);
          return {
            ...f,
            permissions: { ...f.permissions, quarantine: newQuarantine },
          };
        }
        return f;
      })
    );
  };

  const handleToggleFavorite = (fileId: string) => {
    setFiles(prev =>
      prev.map(f => {
        if (f.id === fileId) {
          return { ...f, isFavorite: !f.isFavorite };
        }
        return f;
      })
    );
  };

  const handleRename = (fileId: string, newName: string) => {
    setFiles(prev =>
      prev.map(f => {
        if (f.id === fileId) {
          const ext = newName.includes('.') ? newName.split('.').pop()!.toLowerCase() : f.extension;
          showToast(`Renamed to ${newName}`);
          return {
            ...f,
            name: newName,
            extension: ext,
            path: f.path.substring(0, f.path.lastIndexOf('/') + 1) + newName,
          };
        }
        return f;
      })
    );
  };

  const handleDeleteFile = (fileId: string) => {
    setFiles(prev =>
      prev.map(f => {
        if (f.id === fileId) {
          return {
            ...f,
            isTrash: true,
            originalFolderId: f.folderId,
            folderId: 'trash',
          };
        }
        return f;
      })
    );
    showToast('Moved artifact to Quarantine / Trash.');
  };

  const handleRestoreFile = (fileId: string) => {
    setFiles(prev =>
      prev.map(f => {
        if (f.id === fileId) {
          return {
            ...f,
            isTrash: false,
            folderId: f.originalFolderId || 'downloads',
          };
        }
        return f;
      })
    );
    showToast('Restored artifact from trash.');
  };

  const handleBatchQuarantine = () => {
    setFiles(prev =>
      prev.map(f => {
        if (selectedFileIds.has(f.id)) {
          return {
            ...f,
            permissions: { ...f.permissions, quarantine: !f.permissions.quarantine },
          };
        }
        return f;
      })
    );
    showToast(`Updated quarantine state on ${selectedFileIds.size} file(s).`);
  };

  const handleBatchDelete = () => {
    setFiles(prev =>
      prev.map(f => {
        if (selectedFileIds.has(f.id)) {
          return {
            ...f,
            isTrash: true,
            originalFolderId: f.folderId,
            folderId: 'trash',
          };
        }
        return f;
      })
    );
    showToast(`Moved ${selectedFileIds.size} file(s) to quarantine trash.`);
    setSelectedFileIds(new Set());
  };

  const handleCreateFolder = (folderName: string) => {
    const newFolder: Folder = {
      id: `case_${Date.now()}`,
      name: folderName,
      isSystem: false,
    };
    setCustomFolders(prev => [...prev, newFolder]);
    setCurrentFolderId(newFolder.id);
    showToast(`Created case folder "${folderName}"`);
  };

  // --- Presentation Tour Step Handler ---
  const handleApplyTourStep = useCallback((step: TourStep) => {
    if (step.targetFolder) {
      setCurrentFolderId(step.targetFolder);
    }
    if (step.targetFileId) {
      setInspectedFileId(step.targetFileId);
      setSelectedFileIds(new Set([step.targetFileId]));
    } else if (!step.openDrawer) {
      setInspectedFileId(null);
    }
  }, []);

  // --- Global Keyboard Shortcuts ---
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ignore when inside input/textarea
      const activeTag = document.activeElement?.tagName.toLowerCase();
      if (activeTag === 'input' || activeTag === 'textarea' || activeTag === 'select') {
        if (e.key === 'Escape') {
          (document.activeElement as HTMLElement)?.blur();
        }
        return;
      }

      // Space: inspect or clear
      if (e.code === 'Space') {
        e.preventDefault();
        if (selectedFileIds.size > 0) {
          const firstSelectedId = Array.from(selectedFileIds)[0];
          setInspectedFileId(curr => (curr === firstSelectedId ? null : firstSelectedId));
        }
      }

      // Cmd+F or / : search
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'f') {
        e.preventDefault();
        document.getElementById('global-file-search-input')?.focus();
      }
      if (e.key === '/') {
        e.preventDefault();
        document.getElementById('global-file-search-input')?.focus();
      }

      // Cmd+A: select all
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'a') {
        e.preventDefault();
        handleSelectAll();
      }

      // Delete / Backspace
      if (e.key === 'Delete' || e.key === 'Backspace') {
        if (selectedFileIds.size > 0) {
          e.preventDefault();
          handleBatchDelete();
        }
      }

      // G: toggle grid/table
      if (e.key.toLowerCase() === 'g') {
        setViewMode(v => (v === 'grid' ? 'table' : 'grid'));
      }

      // Q: toggle quarantine
      if (e.key.toLowerCase() === 'q') {
        if (selectedFileIds.size > 0) {
          handleBatchQuarantine();
        }
      }

      // Escape
      if (e.key === 'Escape') {
        setSelectedFileIds(new Set());
        setContextMenu(null);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedFileIds, currentFolderFiles]);

  const selectedBytes = useMemo(() => {
    return files.filter(f => selectedFileIds.has(f.id)).reduce((acc, f) => acc + f.size, 0);
  }, [files, selectedFileIds]);

  const totalBytes = useMemo(() => {
    return files.filter(f => !f.isTrash).reduce((acc, f) => acc + f.size, 0);
  }, [files]);

  return (
    <div
      id="sentinel-root-workstation"
      className="flex h-screen w-screen flex-col overflow-hidden bg-[#FAFAFC] text-[#1F1D2B]"
    >
      {/* Hidden file input for manual file uploads */}
      <input
        ref={fileInputRef}
        type="file"
        multiple
        onChange={handleFileInputChange}
        className="hidden"
      />

      {/* Top Bar */}
      <TopBar
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        viewMode={viewMode}
        onViewModeChange={setViewMode}
        sortBy={sortBy}
        sortDirection={sortDirection}
        onSortChange={setSortBy}
        onToggleSortDirection={() => setSortDirection(d => (d === 'asc' ? 'desc' : 'asc'))}
        onImportClick={() => fileInputRef.current?.click()}
        onOpenDiff={() => {
          setDiffModalFile(inspectedFile || files[0] || null);
          setIsDiffModalOpen(true);
        }}
        onOpenReport={() => setIsReportModalOpen(true)}
        onAddSampleData={() => {
          setFiles(INITIAL_SAMPLE_FILES);
          showToast('Loaded standard security test samples.');
        }}
        onOpenPresentationMode={() => setIsPresentationOpen(true)}
      />

      {/* Main Workspace Body (Sidebar + Center Content + Inspector Panel) */}
      <div className="flex flex-1 overflow-hidden">
        {/* Left Sidebar */}
        <Sidebar
          currentFolderId={currentFolderId}
          onSelectFolder={id => {
            setCurrentFolderId(id);
            setSelectedFileIds(new Set());
          }}
          systemFolders={SYSTEM_FOLDERS}
          customFolders={customFolders}
          files={files}
          onCreateFolderClick={() => setIsCreateFolderOpen(true)}
          onOpenDiff={() => {
            setDiffModalFile(inspectedFile || files[0] || null);
            setIsDiffModalOpen(true);
          }}
          onOpenReport={() => setIsReportModalOpen(true)}
          onOpenPresentationMode={() => setIsPresentationOpen(true)}
        />

        {/* Center Area: Dashboard or File Browser */}
        <main className="flex flex-1 flex-col overflow-hidden">
          {currentFolderId === 'dashboard' ? (
            <DashboardView
              files={files}
              onSelectFile={file => {
                setInspectedFileId(file.id);
                setSelectedFileIds(new Set([file.id]));
              }}
              onImportClick={() => fileInputRef.current?.click()}
              onNavigateToFolder={folderId => {
                setCurrentFolderId(folderId);
              }}
            />
          ) : (
            <FileBrowser
              files={currentFolderFiles}
              currentFolderTitle={currentFolderTitle}
              currentFolderId={currentFolderId}
              selectedFileIds={selectedFileIds}
              onToggleSelect={handleToggleSelect}
              onSelectAll={handleSelectAll}
              onClearSelection={handleClearSelection}
              onInspectFile={handleInspectFile}
              onContextMenu={handleContextMenu}
              onBatchQuarantine={handleBatchQuarantine}
              onBatchDelete={handleBatchDelete}
              onFilesDropped={handleFilesDropped}
              onImportClick={() => fileInputRef.current?.click()}
              categoryFilter={categoryFilter}
              onCategoryFilterChange={setCategoryFilter}
              viewMode={viewMode}
            />
          )}
        </main>

        {/* Right Collapsible Cybersecurity Inspection Panel */}
        <InspectorPanel
          file={inspectedFile}
          onClose={() => setInspectedFileId(null)}
          onToggleQuarantine={handleToggleQuarantine}
          onToggleFavorite={handleToggleFavorite}
          onOpenDiff={file => {
            setDiffModalFile(file);
            setIsDiffModalOpen(true);
          }}
        />
      </div>

      {/* Bottom Status Bar */}
      <StatusBar
        selectedCount={selectedFileIds.size}
        selectedBytes={selectedBytes}
        totalFilesCount={files.filter(f => !f.isTrash).length}
        totalBytes={totalBytes}
        currentFolderTitle={currentFolderTitle}
        operationStatus={operationStatus}
        onOpenShortcuts={() => setIsShortcutsOpen(true)}
      />

      {/* Floating Action / Toast Notification */}
      {toastMessage && (
        <div
          id="sentinel-toast-notification"
          className="fixed bottom-10 left-1/2 -translate-x-1/2 z-50 rounded-lg bg-slate-900 px-4 py-2 text-xs font-semibold text-white shadow-xl border border-slate-700 animate-in fade-in slide-in-from-bottom-2 duration-150 flex items-center gap-2"
        >
          <span className="h-2 w-2 rounded-full bg-purple-400"></span>
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Context Menu */}
      {contextMenu && (
        <ContextMenu
          x={contextMenu.x}
          y={contextMenu.y}
          file={contextMenu.file}
          onClose={() => setContextMenu(null)}
          onInspect={handleInspectFile}
          onOpenDiff={file => {
            setDiffModalFile(file);
            setIsDiffModalOpen(true);
          }}
          onToggleQuarantine={handleToggleQuarantine}
          onToggleFavorite={handleToggleFavorite}
          onRename={file => setRenamingFile(file)}
          onDelete={handleDeleteFile}
          onRestore={handleRestoreFile}
        />
      )}

      {/* File Differential Tool Modal */}
      {isDiffModalOpen && (
        <FileDiffModal
          files={files.filter(f => !f.isTrash)}
          initialFileA={diffModalFile}
          onClose={() => setIsDiffModalOpen(false)}
        />
      )}

      {/* Security Audit Report Modal */}
      {isReportModalOpen && (
        <SecurityReportModal
          files={files}
          onClose={() => setIsReportModalOpen(false)}
        />
      )}

      {/* Create Case Folder Modal */}
      <CreateFolderModal
        isOpen={isCreateFolderOpen}
        onClose={() => setIsCreateFolderOpen(false)}
        onCreateFolder={handleCreateFolder}
      />

      {/* Rename File Modal */}
      <RenameModal
        file={renamingFile}
        onClose={() => setRenamingFile(null)}
        onRename={handleRename}
      />

      {/* Keyboard Shortcuts Modal */}
      <KeyboardShortcutsModal
        isOpen={isShortcutsOpen}
        onClose={() => setIsShortcutsOpen(false)}
      />

      {/* Interactive Presentation Mode Tour */}
      <PresentationMode
        isOpen={isPresentationOpen}
        onClose={() => setIsPresentationOpen(false)}
        onApplyStepState={handleApplyTourStep}
        onOpenDiff={() => {
          setDiffModalFile(inspectedFile || files[0] || null);
          setIsDiffModalOpen(true);
        }}
        onOpenReport={() => setIsReportModalOpen(true)}
      />
    </div>
  );
}
