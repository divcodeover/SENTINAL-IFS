export type RiskLevel = 'clean' | 'low' | 'medium' | 'high' | 'critical';

export interface RiskIndicator {
  id: string;
  level: 'info' | 'warning' | 'danger';
  title: string;
  description: string;
}

export interface ExtractedString {
  str: string;
  offset: number;
  isSuspicious: boolean;
  category?: 'network' | 'execution' | 'registry' | 'cryptography' | 'persistence' | 'general';
}

export interface FilePermissions {
  read: boolean;
  write: boolean;
  execute: boolean;
  quarantine: boolean;
}

export interface CyberFile {
  id: string;
  name: string;
  path: string;
  folderId: string;
  size: number;
  extension: string;
  mimeType: string;
  createdAt: string;
  modifiedAt: string;
  sha256: string;
  sha1: string;
  md5: string;
  entropy: number; // 0.00 to 8.00
  entropyInterpretation: 'Low (Structured/Text)' | 'Normal (Standard data)' | 'High (Compressed/Encrypted/Packed)';
  byteDistribution: number[]; // 256 byte frequency counts or ratios for histogram
  magicBytes: string;
  detectedType: string;
  isUntrusted: boolean;
  riskLevel: RiskLevel;
  riskScore: number; // 0 to 100
  riskIndicators: RiskIndicator[];
  permissions: FilePermissions;
  isFavorite: boolean;
  isTrash: boolean;
  originalFolderId?: string; // used when moved to trash
  extractedStrings: ExtractedString[];
  hexSample: number[]; // raw byte numbers for hex viewer
  textContent?: string;
  quarantinedAt?: string;
}

export interface Folder {
  id: string;
  name: string;
  icon?: string;
  isSystem: boolean;
  parentId?: string;
}

export type ViewMode = 'grid' | 'table';

export type SortField = 'name' | 'size' | 'modifiedAt' | 'entropy' | 'riskLevel';
export type SortDirection = 'asc' | 'desc';

export type CategoryFilter = 
  | 'all' 
  | 'executables' 
  | 'scripts' 
  | 'archives' 
  | 'documents' 
  | 'media' 
  | 'quarantined' 
  | 'high_risk';

export interface FileFilterState {
  searchQuery: string;
  category: CategoryFilter;
  sortBy: SortField;
  sortDirection: SortDirection;
  viewMode: ViewMode;
}

export interface SystemStats {
  totalFiles: number;
  totalBytes: number;
  highRiskCount: number;
  mediumRiskCount: number;
  cleanCount: number;
  quarantinedCount: number;
  categoryCounts: Record<string, number>;
}
